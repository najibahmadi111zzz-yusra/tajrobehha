package com.tajro.app;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TextView view = new TextView(this);
        view.setText("تجربه‌ها\n\nنسخه آزمایشی برنامه آماده است.");
        view.setTextSize(22);
        view.setPadding(40, 80, 40, 40);
        setContentView(view);
    }
}
