package com.tajro.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends Activity {

    private RewardedAdManager rewardedAdManager;
    private InterstitialAdManager interstitialAdManager;

    private static final String DEVELOPER_EMAIL =
            "najibahmadi111zzz@gmail.com";

    private LinearLayout mainLayout;
    private TextView title;
    private TextView welcome;
    private TextView footer;
    private String appliedLanguage;

    private Button listButton;
    private Button chatButton;
    private Button aiButton;
    private Button exchangeButton;
    private Button settingsButton;
    private Button rewardedButton;
    private Button gameButton;

    private ImageView backgroundImage;

    // اعمال زبان قبل از ساخت صفحه
    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(
                LanguageManager.applyLanguage(newBase)
        );
    }

    private int dp(int value) {
        return (int) (
                value *
                getResources()
                        .getDisplayMetrics()
                        .density
        );
    }

    // بررسی سازنده برنامه
    private boolean isDeveloper() {
        try {
            FirebaseUser user =
                    FirebaseAuth.getInstance().getCurrentUser();

            if (user == null) {
                return false;
            }

            String email = user.getEmail();

            return email != null
                    && DEVELOPER_EMAIL.equalsIgnoreCase(
                    email.trim()
            );

        } catch (Exception e) {
            return false;
        }
    }

    // متن بر اساس زبان
    private String text(
            String fa,
            String en,
            String ps,
            String ur,
            String hi
    ) {
        String language =
                LanguageManager.getLanguage(this);

        if ("en".equals(language)) {
            return en;
        }

        if ("ps".equals(language)) {
            return ps;
        }

        if ("ur".equals(language)) {
            return ur;
        }

        if ("hi".equals(language)) {
            return hi;
        }

        return fa;
    }

    // متن شش‌زبانه برای نام بازی‌ها
    private String text(String fa, String en, String ps, String ur, String hi, String ar) {
        String language = LanguageManager.getLanguage(this);
        if ("ar".equals(language)) return ar;
        return text(fa, en, ps, ur, hi);
    }

    // ساخت دکمه
    private Button createButton(String text) {
        Button button = new Button(this);

        button.setText(text);
        button.setTextSize(16);
        button.setTextColor(Color.WHITE);

        button.setTypeface(
                Typeface.DEFAULT,
                Typeface.BOLD
        );

        button.setGravity(Gravity.CENTER);


        LinearLayout.LayoutParams params =
                new LinearLayout.LayoutParams(
                        0,
                        dp(65),
                        1
                );

        params.setMargins(
                dp(6),
                dp(6),
                dp(6),
                dp(6)
        );

        button.setLayoutParams(params);

        return button;
    }

    // ظاهر دکمه‌ها
    private void styleButton(Button button) {
        GradientDrawable background =
                new GradientDrawable();

        background.setColor(
                ThemeManager.getThemeColor(this)
        );

        background.setCornerRadius(dp(18));

        button.setBackground(background);
        button.setTextColor(Color.WHITE);
    }

    // تصویر پس‌زمینه
    private ImageView createBackgroundImage() {
        ImageView imageView = new ImageView(this);

        imageView.setImageResource(
                R.drawable.tajrobehha_background
        );

        imageView.setScaleType(
                ImageView.ScaleType.CENTER_CROP
        );

        imageView.setAlpha(1.0f);

        imageView.setClickable(false);
        imageView.setFocusable(false);

        return imageView;
    }

    // onCreate
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        appliedLanguage =
                LanguageManager.getLanguage(this);

        // قفل امنیتی
        if (AppLockManager.hasPassword(this)
                && AppLockManager.isLockEnabled(this)
                && !AppLockManager.isSessionUnlocked(this)) {

            Intent lockIntent =
                    new Intent(
                            MainActivity.this,
                            AppLockActivity.class
                    );

            startActivity(lockIntent);
            finish();

            return;
        }

        // Unity Rewarded Ad
        rewardedAdManager =
                new RewardedAdManager(this);

        rewardedAdManager.loadRewardedAd();

        // Unity Interstitial Ad
        interstitialAdManager =
                new InterstitialAdManager(this);

        interstitialAdManager.loadInterstitialAd();

        // لایه اصلی
        FrameLayout rootLayout =
                new FrameLayout(this);

        rootLayout.setLayoutParams(
                new ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                )
        );

        rootLayout.setBackgroundColor(
                Color.TRANSPARENT
        );

        // عکس پس‌زمینه
        backgroundImage =
                createBackgroundImage();

        FrameLayout.LayoutParams backgroundParams =
                new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                );

        backgroundParams.gravity =
                Gravity.CENTER;

        rootLayout.addView(
                backgroundImage,
                backgroundParams
        );

        // ScrollView
        ScrollView scrollView =
                new ScrollView(this);

        scrollView.setFillViewport(true);
        scrollView.setVerticalScrollBarEnabled(false);

        // صفحه اصلی
        mainLayout =
                new LinearLayout(this);

        mainLayout.setOrientation(
                LinearLayout.VERTICAL
        );

        mainLayout.setPadding(
                dp(20),
                dp(35),
                dp(20),
                dp(25)
        );

        mainLayout.setBackgroundColor(
                Color.TRANSPARENT
        );

        scrollView.addView(
                mainLayout,
                new ScrollView.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                )
        );

        // لوگو
        TextView logo =
                new TextView(this);

        logo.setText("📖💡");
        logo.setTextSize(52);
        logo.setGravity(Gravity.CENTER);

        // عنوان
        title =
                new TextView(this);

        title.setText(
                text(
                        "تجربه‌ها",
                        "Experiences",
                        "تجربې",
                        "تجربات",
                        "अनुभव"
                )
        );

        title.setTextSize(34);

        title.setTypeface(
                Typeface.DEFAULT,
                Typeface.BOLD
        );

        title.setGravity(
                Gravity.CENTER
        );

        title.setPadding(
                0,
                dp(5),
                0,
                dp(8)
        );

        // خوش‌آمدگویی
        welcome =
                new TextView(this);

        welcome.setText(
                text(
                        "تجربه‌های خود را ثبت کنید و با دیگران شریک شوید",
                        "Share your experiences and learn from others",
                        "خپلې تجربې ثبت کړئ او له نورو سره یې شریکې کړئ",
                        "اپنے تجربات درج کریں اور دوسروں کے ساتھ شیئر کریں",
                        "अपने अनुभव दर्ज करें और दूसरों के साथ साझा करें"
                )
        );

        welcome.setTextSize(17);
        welcome.setGravity(Gravity.CENTER);

        welcome.setPadding(
                dp(10),
                dp(5),
                dp(10),
                dp(30)
        );

        mainLayout.addView(logo);
        mainLayout.addView(title);
        mainLayout.addView(welcome);

        // ردیف اول
        LinearLayout row1 =
                new LinearLayout(this);

        row1.setOrientation(
                LinearLayout.HORIZONTAL
        );


        listButton =
                createButton(
                        text(
                                "📚 دیدن تجربه‌ها",
                                "📚 View Experiences",
                                "📚 تجربې کتل",
                                "📚 تجربات دیکھیں",
                                "📚 अनुभव देखें"
                        )
                );

        row1.addView(listButton);

        // ردیف دوم
        LinearLayout row2 =
                new LinearLayout(this);

        row2.setOrientation(
                LinearLayout.HORIZONTAL
        );

        chatButton =
                createButton(
                        text(
                                "💬 چت",
                                "💬 Chat",
                                "💬 خبرې",
                                "💬 چیٹ",
                                "💬 चैट"
                        )
                );

        aiButton =
                createButton(
                        text(
                                "🤖 دستیار هوشمند",
                                "🤖 AI Assistant",
                                "🤖 هوښیار مرستیال",
                                "🤖 ذہین معاون",
                                "🤖 स्मार्ट सहायक"
                        )
                );

        row2.addView(chatButton);
        row2.addView(aiButton);

        // ردیف سوم
        LinearLayout row3 =
                new LinearLayout(this);

        row3.setOrientation(
                LinearLayout.HORIZONTAL
        );

        exchangeButton =
                createButton(
                        text(
                                "💱 صرافی",
                                "💱 Exchange",
                                "💱 صرافي",
                                "💱 صرافی",
                                "💱 मुद्रा विनिमय"
                        )
                );

        settingsButton =
                createButton(
                        text(
                                "⚙️ تنظیمات",
                                "⚙️ Settings",
                                "⚙️ ترتیبات",
                                "⚙️ ترتیبات",
                                "⚙️ सेटिंग्स"
                        )
                );

        row3.addView(exchangeButton);
        row3.addView(settingsButton);

        // بازی
        gameButton =
                createButton(
                        text(
                                "🎮 بازی‌ها: توپ و مرتب‌سازی رنگ",
                                "🎮 Games: Ball & Color Sort",
                                "🎮 لوبې: توپ او د رنګونو ترتیب",
                                "🎮 کھیل: گیند اور رنگوں کی ترتیب",
                                "🎮 खेल: गेंद और रंगों की सजावट",
                                "🎮 الألعاب: الكرة وترتيب الألوان"
                        )
                );

        LinearLayout.LayoutParams gameParams =
                new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        dp(65)
                );

        gameParams.setMargins(
                dp(6),
                dp(6),
                dp(6),
                dp(6)
        );

        gameButton.setLayoutParams(
                gameParams
        );

        // دکمه حمایت از تجربه‌ها
        rewardedButton =
                createButton(
                        text(
                                "🎁 حمایت از تجربه‌ها",
                                "🎁 Support Experiences",
                                "🎁 د تجربو ملاتړ",
                                "🎁 تجربات کی حمایت",
                                "🎁 अनुभवों का समर्थन"
                        )
                );

        LinearLayout.LayoutParams rewardedParams =
                new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        dp(65)
                );

        rewardedParams.setMargins(
                dp(6),
                dp(6),
                dp(6),
                dp(2)
        );

        rewardedButton.setLayoutParams(
                rewardedParams
        );

        // توضیح حمایت به پنج زبان
        TextView supportDescription =
                new TextView(this);

        supportDescription.setText(
                text(
                        "با تماشای یک تبلیغ کوتاه از توسعهٔ برنامه حمایت کنید",
                        "Support the development of the app by watching a short ad.",
                        "د لنډ اعلان په کتلو سره د اپلېکېشن له پرمختګ څخه ملاتړ وکړئ.",
                        "ایک مختصر اشتہار دیکھ کر ایپ کی ترقی میں مدد کریں۔",
                        "एक छोटा विज्ञापन देखकर ऐप के विकास में सहयोग करें।"
                )
        );

        supportDescription.setTextSize(14);
        supportDescription.setGravity(Gravity.CENTER);

        supportDescription.setPadding(
                dp(8),
                dp(4),
                dp(8),
                dp(10)
        );

        // اضافه کردن بخش‌ها
        mainLayout.addView(row1);
        mainLayout.addView(row2);
        mainLayout.addView(row3);
        mainLayout.addView(gameButton);
        mainLayout.addView(rewardedButton);
        mainLayout.addView(supportDescription);

        // پایین صفحه
        footer =
                new TextView(this);

        footer.setText(
                text(
                        "تجربه‌ها • یاد بگیر • شریک کن",
                        "Experiences • Learn • Share",
                        "تجربې • زده کړه • شریک یې کړه",
                        "تجربات • سیکھیں • شیئر کریں",
                        "अनुभव • सीखें • साझा करें"
                )
        );

        footer.setTextSize(14);
        footer.setGravity(Gravity.CENTER);

        footer.setPadding(
                0,
                dp(30),
                0,
                dp(10)
        );

        mainLayout.addView(footer);

        // دیدن تجربه‌ها
        listButton.setOnClickListener(v -> {

            interstitialAdManager
                    .showInterstitialIfAllowed();

            Intent intent =
                    new Intent(
                            MainActivity.this,
                            ExperienceListActivity.class
                    );

            startActivity(intent);
        });

        // چت
        chatButton.setOnClickListener(v -> {

            Intent intent =
                    new Intent(
                            MainActivity.this,
                            ChatActivity.class
                    );

            startActivity(intent);
        });

        // دستیار هوشمند
        aiButton.setOnClickListener(v -> {

            Intent intent =
                    new Intent(
                            MainActivity.this,
                            AIActivity.class
                    );

            startActivity(intent);
        });

        // صرافی
        exchangeButton.setOnClickListener(v -> {

            interstitialAdManager
                    .showInterstitialIfAllowed();

            Intent intent =
                    new Intent(
                            MainActivity.this,
                            ExchangeActivity.class
                    );

            startActivity(intent);
        });

        // تنظیمات
        settingsButton.setOnClickListener(v -> {

            Intent intent =
                    new Intent(
                            MainActivity.this,
                            SettingsActivity.class
                    );

            startActivity(intent);
        });

        // بازی
        gameButton.setOnClickListener(v -> {

            Intent intent =
                    new Intent(
                            MainActivity.this,
                            GamesActivity.class
                    );

            startActivity(intent);
        });

        // تبلیغ اختیاری برای حمایت از برنامه
        rewardedButton.setOnClickListener(v -> {

            rewardedAdManager.showRewardedAd(
                    new RewardedAdManager.RewardListener() {

                        @Override
                        public void onRewarded() {
                            // تبلیغ برای حمایت از برنامه است؛
                            // هیچ جایزه‌ای به کاربر وعده داده نمی‌شود.
                        }

                        @Override
                        public void onAdNotReady() {

                            if (isDeveloper()) {

                                Toast.makeText(
                                        MainActivity.this,
                                        text(
                                                "⏳ تبلیغ هنوز آماده نیست، چند لحظه بعد دوباره امتحان کنید.",
                                                "⏳ The ad is not ready yet. Try again shortly.",
                                                "⏳ اعلان لا تر اوسه چمتو نه دی، لږ وروسته بیا هڅه وکړئ.",
                                                "⏳ اشتہار ابھی تیار نہیں، کچھ دیر بعد دوبارہ کوشش کریں۔",
                                                "⏳ विज्ञापन अभी तैयार नहीं है, थोड़ी देर बाद फिर कोशिश करें।"
                                        ),
                                        Toast.LENGTH_SHORT
                                ).show();
                            }
                        }

                        @Override
                        public void onAdFailed() {

                            if (isDeveloper()) {

                                Toast.makeText(
                                        MainActivity.this,
                                        text(
                                                "❌ نمایش تبلیغ ناموفق بود.",
                                                "❌ Ad failed to display.",
                                                "❌ د اعلان ښودل ناکام شول.",
                                                "❌ اشتہار دکھانے میں ناکامی ہوئی۔",
                                                "❌ विज्ञापन दिखाने में विफल रहा।"
                                        ),
                                        Toast.LENGTH_SHORT
                                ).show();
                            }
                        }
                    }
            );
        });

        // قرار دادن ScrollView
        FrameLayout.LayoutParams contentParams =
                new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                );

        contentParams.gravity =
                Gravity.CENTER;

        rootLayout.addView(
                scrollView,
                contentParams
        );

  // نمایش صفحه
setContentView(rootLayout);

// اعمال رنگ و حالت شب
applyTheme();

// درخواست اجازه نمایش اعلان‌ها
requestNotificationPermission();
        
    }
    private void requestNotificationPermission() {
    if (Build.VERSION.SDK_INT >= 33) {

        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {

            requestPermissions(
                    new String[]{Manifest.permission.POST_NOTIFICATIONS},
                    1001
            );
        }
    }
  }

    // برگشت از تنظیمات
    @Override
    protected void onResume() {
        super.onResume();

        if (mainLayout != null) {

            String currentLanguage =
                    LanguageManager.getLanguage(this);

            if (appliedLanguage != null
                    && !currentLanguage.equals(appliedLanguage)) {

                appliedLanguage = currentLanguage;

                recreate();
                return;
            }

            applyTheme();
        }
    }

    // زبان فعلی صفحه
    private String getAppliedLanguage() {

        return getSharedPreferences(
                "tajrobehha_settings",
                MODE_PRIVATE
        ).getString(
                "main_activity_language",
                LanguageManager.getLanguage(this)
        );
    }

    // اعمال رنگ و حالت شب
    private void applyTheme() {

        boolean night =
                ThemeManager.isNightMode(this);

        int themeColor =
                ThemeManager.getThemeColor(this);

        mainLayout.setBackgroundColor(
                Color.TRANSPARENT
        );

        if (backgroundImage != null) {

            backgroundImage.setAlpha(0.35f);

            backgroundImage.setScaleX(1.0f);
            backgroundImage.setScaleY(1.0f);
        }

        if (night) {

            title.setTextColor(Color.WHITE);

        } else {

            title.setTextColor(themeColor);
        }

        welcome.setTextColor(
                ThemeManager.getNormalTextColor(this)
        );

        if (night) {

            footer.setTextColor(Color.LTGRAY);

        } else {

            footer.setTextColor(Color.GRAY);
        }

        styleButton(listButton);
        styleButton(chatButton);
        styleButton(aiButton);
        styleButton(exchangeButton);
        styleButton(settingsButton);
        styleButton(gameButton);
        styleButton(rewardedButton);
    }
          }
