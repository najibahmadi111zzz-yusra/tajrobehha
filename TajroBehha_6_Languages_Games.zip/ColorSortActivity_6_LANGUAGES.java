package com.tajro.app;

import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class ColorSortActivity extends Activity {

    private SortGameView gameView;

    // متن‌های بازی بر اساس زبان انتخاب‌شده در برنامه
    private String tr(String fa, String en, String ps, String ur, String hi, String ar) {
        String language = LanguageManager.getLanguage(this);
        switch (language) {
            case "en": return en;
            case "ps": return ps;
            case "ur": return ur;
            case "hi": return hi;
            case "ar": return ar;
            default: return fa;
        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);

        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN
        );

        gameView = new SortGameView();
        setContentView(gameView);
    }

    @Override
    protected void onPause() {
        super.onPause();

        if (gameView != null) {
            gameView.stopAnimation();
            gameView.releaseAudio();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (gameView != null) {
            gameView.startAnimation();
        }
    }

    class SortGameView extends View {

        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final float[] colorHsvScratch = new float[3];

        private final Handler handler = new Handler();
        private final Random random = new Random();

        private final SharedPreferences progressPrefs =
                ColorSortActivity.this.getSharedPreferences(
                        "color_sort_progress",
                        MODE_PRIVATE
                );

        /* =========================================================
           AUDIO
           ========================================================= */

        private volatile AudioTrack activeAudioTrack;
        private Thread soundThread;
        private volatile AudioTrack ambientAudioTrack;
        private volatile boolean ambientRunning = false;
        private Thread ambientThread;

        private boolean soundEnabled = true;

        /* =========================================================
           ANIMATION
           ========================================================= */

        private float liquidWave = 0f;
        private float bottleGlow = 0f;

        private long victoryStart = 0L;

        private final Random sparkleRandom = new Random(7319);

        private float[] particleX = new float[42];
        private float[] particleY = new float[42];
        private float[] particleSpeed = new float[42];
        private float[] particleSize = new float[42];
        private float[] particlePhase = new float[42];

        /* =========================================================
           GAME DATA
           ========================================================= */

        private final List<List<Integer>> tubes = new ArrayList<>();
        private final List<Move> history = new ArrayList<>();

        private int selectedTube = -1;

        private int level = 1;
        private int moves = 0;

        private int coins = 0;
        private int totalStars = 0;
        private int lastEarnedCoins = 0;

        private boolean levelFinished = false;
        private boolean levelFailed = false;

        private boolean running = true;

        private long animStart = 0L;

        private int animFrom = -1;
        private int animTo = -1;
        private int animColor = -1;
        private int animAmount = 0;

        private float animProgress = 1f;

        /* =========================================================
           ERROR / FAILURE SYSTEM
           ========================================================= */

        private int mistakes = 0;
        private final int MAX_MISTAKES = 4;

        private int errorFrom = -1;
        private int errorTo = -1;

        private long errorStart = 0L;
        private int errorStrength = 0;

        private long failureStart = 0L;

        /* =========================================================
           CONSTANTS
           ========================================================= */

        private final int MAX_LEVEL = 50;
        private final int CAPACITY = 4;

        private final int[] colors = {
                Color.rgb(255, 53, 69),
                Color.rgb(38, 111, 255),
                Color.rgb(41, 220, 78),
                Color.rgb(255, 193, 25),
                Color.rgb(164, 65, 245),
                Color.rgb(18, 194, 229),
                Color.rgb(255, 80, 180),
                Color.rgb(255, 132, 26),
                Color.rgb(126, 73, 245),
                Color.rgb(30, 220, 175),
                Color.rgb(255, 92, 214),
                Color.rgb(116, 205, 255)
        };

        /* =========================================================
           FRAME LOOP
           ========================================================= */

        private final Runnable frame = new Runnable() {

            @Override
            public void run() {

                if (!running) {
                    return;
                }

                liquidWave += 0.17f;
                bottleGlow += 0.045f;

                invalidate();

                // Keep pours and short feedback effects fluid; use a lighter
                // 30 FPS cadence while the player is thinking to reduce heat
                // and battery use on entry-level Android phones.
                long now = SystemClock.uptimeMillis();
                boolean shortEffect = errorStart > 0 && now - errorStart < 650;
                boolean activeMove = animProgress < 1f;
                handler.postDelayed(this,
                        (activeMove || shortEffect || levelFinished || levelFailed) ? 16 : 33);
            }
        };

        /* =========================================================
           CONSTRUCTOR
           ========================================================= */

        SortGameView() {

            super(ColorSortActivity.this);

            setLayerType(View.LAYER_TYPE_SOFTWARE, null);

            p.setAntiAlias(true);
            stroke.setAntiAlias(true);
            text.setAntiAlias(true);

            setFocusable(true);
            setContentDescription(tr("بازی مرتب‌سازی رنگ‌ها؛ لمس ظرف‌ها برای انتقال مایع", "Color Sort; tap bottles to pour", "د رنګونو ترتیب؛ د مایع بدلولو لپاره بوتلونه لمس کړئ", "رنگوں کی ترتیب؛ مائع منتقل کرنے کے لیے بوتلوں کو چھوئیں", "रंगों को क्रम में लगाएँ; तरल डालने के लिए बोतलों को छुएँ", "ترتيب الألوان؛ المس الزجاجات لنقل السائل"));

            soundEnabled = progressPrefs.getBoolean("sound", true);

            level = Math.max(
                    1,
                    Math.min(
                            MAX_LEVEL,
                            progressPrefs.getInt("level", 1)
                    )
            );

            coins = Math.max(
                    0,
                    progressPrefs.getInt("coins", 0)
            );

            totalStars = Math.max(
                    0,
                    progressPrefs.getInt("stars", 0)
            );

            prepareVictoryParticles();

            resetLevel();
        }

        /* =========================================================
           ANIMATION CONTROL
           ========================================================= */

        void startAnimation() {

            running = true;

            handler.removeCallbacks(frame);
            handler.post(frame);
            startAmbientMusic();
        }

        void stopAnimation() {

            running = false;

            handler.removeCallbacks(frame);

            stopActiveSound();
            stopAmbientMusic();

            saveProgress();
        }

        /* =========================================================
           AUDIO SYSTEM
           ========================================================= */

        private void playGameSound(final int kind) {

            if (!soundEnabled) {
                return;
            }

            stopActiveSound();

            soundThread = new Thread(new Runnable() {

                @Override
                public void run() {

                    final int sampleRate = 44100;

                    int durationMs;

                    if (kind == 1) {
                        durationMs = 120;
                    } else if (kind == 2) {
                        durationMs = 620;
                    } else if (kind == 3) {
                        durationMs = 3400;
                    } else if (kind == 4) {
                        durationMs = 720;
                    } else {
                        durationMs = 150;
                    }

                    final int totalSamples =
                            sampleRate * durationMs / 1000;

                    int minBuffer = AudioTrack.getMinBufferSize(
                            sampleRate,
                            AudioFormat.CHANNEL_OUT_MONO,
                            AudioFormat.ENCODING_PCM_16BIT
                    );

                    if (minBuffer <= 0) {
                        minBuffer = 4096;
                    }

                    AudioTrack track = null;

                    try {

                        track = new AudioTrack(
                                AudioManager.STREAM_MUSIC,
                                sampleRate,
                                AudioFormat.CHANNEL_OUT_MONO,
                                AudioFormat.ENCODING_PCM_16BIT,
                                Math.max(minBuffer, 8192),
                                AudioTrack.MODE_STREAM
                        );

                        activeAudioTrack = track;

                        track.play();

                        byte[] buffer = new byte[8192];

                        int position = 0;

                        float phase1 = 0f;
                        float phase2 = 0f;
                        float phase3 = 0f;
                        float phase4 = 0f;

                        float filteredNoise = 0f;

                        while (
                                position < totalSamples
                                        && soundEnabled
                                        && activeAudioTrack == track
                        ) {

                            int frames = Math.min(
                                    buffer.length / 2,
                                    totalSamples - position
                            );

                            for (int i = 0; i < frames; i++) {

                                int sampleIndex = position + i;

                                float q =
                                        sampleIndex /
                                                (float) Math.max(
                                                        1,
                                                        totalSamples - 1
                                                );

                                float value = 0f;

                                /* ---------------------------------
                                   SIMPLE CLICK
                                   --------------------------------- */

                                if (kind == 1) {

                                    float freq = 690f;

                                    phase1 +=
                                            (float) (
                                                    2.0 *
                                                            Math.PI *
                                                            freq /
                                                            sampleRate
                                            );

                                    float envelope =
                                            (float) Math.exp(
                                                    -q * 7.0
                                            );

                                    value =
                                            (float) Math.sin(phase1)
                                                    * envelope
                                                    * 0.22f;

                                }

                                /* ---------------------------------
                                   POUR SOUND
                                   --------------------------------- */

                                else if (kind == 2) {

                                    float raw =
                                            random.nextFloat() * 2f - 1f;

                                    filteredNoise +=
                                            (raw - filteredNoise)
                                                    * 0.075f;

                                    phase1 +=
                                            (float) (
                                                    2.0 *
                                                            Math.PI *
                                                            175 /
                                                            sampleRate
                                            );

                                    phase2 +=
                                            (float) (
                                                    2.0 *
                                                            Math.PI *
                                                            365 /
                                                            sampleRate
                                            );

                                    float envelope =
                                            (float) Math.sin(
                                                    Math.PI * q
                                            );

                                    value =
                                            (
                                                    filteredNoise * 0.70f
                                                            +
                                                            (float) Math.sin(phase1)
                                                                    * 0.13f
                                                            +
                                                            (float) Math.sin(phase2)
                                                                    * 0.07f
                                            )
                                                    * envelope
                                                    * 0.82f;
                                }

                                /* ---------------------------------
                                   LONG VICTORY MELODY
                                   --------------------------------- */

                                else if (kind == 3) {

                                    float[] notes = {
                                            523.25f,
                                            659.25f,
                                            783.99f,
                                            1046.50f,
                                            783.99f,
                                            987.77f,
                                            1174.66f,
                                            1046.50f,
                                            1318.51f,
                                            1567.98f
                                    };

                                    float noteLength =
                                            0.32f;

                                    int noteIndex =
                                            (int) (q * notes.length /
                                                    noteLength);

                                    noteIndex =
                                            noteIndex % notes.length;

                                    float notePos =
                                            (q * 3.125f)
                                                    % 1f;

                                    float melodyFreq =
                                            notes[noteIndex];

                                    phase1 +=
                                            (float) (
                                                    2.0 *
                                                            Math.PI *
                                                            melodyFreq /
                                                            sampleRate
                                            );

                                    phase2 +=
                                            (float) (
                                                    2.0 *
                                                            Math.PI *
                                                            melodyFreq *
                                                            0.5 /
                                                            sampleRate
                                            );

                                    phase3 +=
                                            (float) (
                                                    2.0 *
                                                            Math.PI *
                                                            104.66 /
                                                            sampleRate
                                            );

                                    phase4 +=
                                            (float) (
                                                    2.0 *
                                                            Math.PI *
                                                            156.80 /
                                                            sampleRate
                                            );

                                    float attack =
                                            Math.min(
                                                    1f,
                                                    notePos / 0.10f
                                            );

                                    float release =
                                            Math.min(
                                                    1f,
                                                    (1f - notePos) / 0.18f
                                            );

                                    float noteEnvelope =
                                            Math.min(
                                                    attack,
                                                    release
                                            );

                                    float overall;

                                    if (q < 0.08f) {
                                        overall = q / 0.08f;
                                    } else if (q > 0.90f) {
                                        overall =
                                                (1f - q) / 0.10f;
                                    } else {
                                        overall = 1f;
                                    }

                                    float sparkle =
                                            (float) Math.sin(
                                                    phase1
                                            ) * 0.24f;

                                    float harmony =
                                            (float) Math.sin(
                                                    phase2
                                            ) * 0.09f;

                                    float bass =
                                            (float) Math.sin(
                                                    phase3
                                            ) * 0.07f;

                                    float high =
                                            (float) Math.sin(
                                                    phase4
                                            ) * 0.035f;

                                    value =
                                            (
                                                    sparkle
                                                            + harmony
                                                            + bass
                                                            + high
                                            )
                                                    * noteEnvelope
                                                    * overall;

                                    /*
                                     * Final sparkle section.
                                     */
                                    if (q > 0.76f) {

                                        float sparkleEnv =
                                                (float) Math.sin(
                                                        (q - 0.76f)
                                                                * Math.PI
                                                                * 12f
                                                );

                                        value +=
                                                sparkleEnv
                                                        * 0.035f;
                                    }
                                }

                                /* ---------------------------------
                                   ERROR SOUND
                                   --------------------------------- */

                                else if (kind == 4) {

                                    float envelope =
                                            (float) Math.exp(
                                                    -q * 4.5f
                                            );

                                    float freq =
                                            410f - q * 180f;

                                    phase1 +=
                                            (float) (
                                                    2.0 *
                                                            Math.PI *
                                                            freq /
                                                            sampleRate
                                            );

                                    phase2 +=
                                            (float) (
                                                    2.0 *
                                                            Math.PI *
                                                            freq *
                                                            1.7 /
                                                            sampleRate
                                            );

                                    value =
                                            (
                                                    (float) Math.sin(phase1)
                                                            * 0.19f
                                                            +
                                                            (float) Math.sin(phase2)
                                                                    * 0.07f
                                            )
                                                    * envelope;
                                }

                                int pcm =
                                        Math.max(
                                                -32767,
                                                Math.min(
                                                        32767,
                                                        (int)
                                                                (
                                                                        value
                                                                                * 15000f
                                                                )
                                                )
                                        );

                                buffer[i * 2] =
                                        (byte) (pcm & 255);

                                buffer[i * 2 + 1] =
                                        (byte) ((pcm >> 8) & 255);
                            }

                            track.write(
                                    buffer,
                                    0,
                                    frames * 2
                            );

                            position += frames;
                        }

                        try {
                            track.stop();
                        } catch (Exception ignored) {
                        }

                    } catch (Exception ignored) {

                    } finally {

                        if (track != null) {

                            try {
                                track.release();
                            } catch (Exception ignored) {
                            }
                        }

                        if (activeAudioTrack == track) {
                            activeAudioTrack = null;
                        }
                    }
                }
            });

            soundThread.start();
        }

        private void stopActiveSound() {

            AudioTrack track = activeAudioTrack;

            activeAudioTrack = null;

            if (track != null) {

                try {
                    track.pause();
                } catch (Exception ignored) {
                }

                try {
                    track.flush();
                } catch (Exception ignored) {
                }

                try {
                    track.release();
                } catch (Exception ignored) {
                }
            }
        }

        void releaseAudio() {
            stopActiveSound();
            stopAmbientMusic();
        }

        /* =========================================================
           SOFT AMBIENT MUSIC + WATER DROPS
           ========================================================= */

        private synchronized void startAmbientMusic() {
            if (!soundEnabled || !running || ambientRunning) return;

            ambientRunning = true;
            ambientThread = new Thread(new Runnable() {
                @Override
                public void run() {
                    // Original, locally synthesized gentle night rain ambience.
                    // No downloaded music, network access, or extra permissions.
                    final int sampleRate = 22050;
                    final int framesPerBlock = 1024;
                    final byte[] buffer = new byte[framesPerBlock * 2];
                    final double twoPi = Math.PI * 2.0;
                    final Random rainRandom = new Random();
                    AudioTrack track = null;
                    long sample = 0L;
                    double filteredRain = 0.0;
                    final double[] pianoNotes = {
                            261.63, 329.63, 392.00, 523.25,
                            392.00, 329.63, 293.66, 349.23,
                            440.00, 587.33, 440.00, 349.23
                    };
                    try {
                        int min = AudioTrack.getMinBufferSize(
                                sampleRate,
                                AudioFormat.CHANNEL_OUT_MONO,
                                AudioFormat.ENCODING_PCM_16BIT
                        );
                        if (min <= 0) min = 4096;
                        track = new AudioTrack(
                                AudioManager.STREAM_MUSIC,
                                sampleRate,
                                AudioFormat.CHANNEL_OUT_MONO,
                                AudioFormat.ENCODING_PCM_16BIT,
                                Math.max(min, buffer.length * 4),
                                AudioTrack.MODE_STREAM
                        );
                        ambientAudioTrack = track;
                        track.play();

                        while (ambientRunning && soundEnabled && running
                                && ambientAudioTrack == track) {
                            for (int i = 0; i < framesPerBlock; i++, sample++) {
                                double seconds = sample / (double) sampleRate;
                                double raw = rainRandom.nextDouble() * 2.0 - 1.0;
                                // Soft low-pass noise gives a distant, steady rainfall texture.
                                filteredRain += (raw - filteredRain) * 0.035;
                                double rain = filteredRain * 0.078;
                                double distantWash = Math.sin(twoPi * 73.4 * seconds)
                                        * Math.sin(twoPi * 0.075 * seconds) * 0.003;

                                // A few rounded water drops, spaced irregularly and kept quiet.
                                double drop = 0.0;
                                double cycle = seconds % 4.7;
                                if (cycle < 0.42) {
                                    double envelope = Math.exp(-cycle * 10.0)
                                            * Math.min(1.0, cycle * 32.0);
                                    double frequency = 1180.0 - 430.0 * cycle;
                                    drop = Math.sin(twoPi * frequency * cycle)
                                            * envelope * 0.022;
                                }
                                // Soft original piano phrase: slow notes with a natural plucked decay.
                                // It is synthesized locally, so no audio file or network permission is needed.
                                double pianoCycle = seconds % 28.8;
                                int pianoIndex = (int) (pianoCycle / 2.4);
                                double noteTime = pianoCycle - pianoIndex * 2.4;
                                double noteFrequency = pianoNotes[pianoIndex % pianoNotes.length];
                                double pianoEnvelope = (1.0 - Math.exp(-noteTime * 13.0))
                                        * Math.exp(-noteTime * 1.18);
                                double piano = Math.sin(twoPi * noteFrequency * noteTime)
                                        * 0.105
                                        + Math.sin(twoPi * noteFrequency * 2.002 * noteTime)
                                        * 0.018
                                        + Math.sin(twoPi * noteFrequency * 0.5 * noteTime)
                                        * 0.025;
                                piano *= pianoEnvelope;

                                // A very quiet sustained chord underneath the melody adds warmth.
                                double chord = Math.sin(twoPi * 130.81 * seconds) * 0.010
                                        + Math.sin(twoPi * 164.81 * seconds) * 0.008
                                        + Math.sin(twoPi * 196.00 * seconds) * 0.007;

                                double slowBreath = 0.82 + 0.18 * Math.sin(twoPi * seconds / 17.0);
                                double value = (rain + distantWash + drop) * slowBreath
                                        + piano + chord;
                                value = Math.tanh(value * 1.65) * 0.58;
                                int pcm = (int) (Math.max(-1.0, Math.min(1.0, value)) * 32700.0);
                                buffer[i * 2] = (byte) (pcm & 255);
                                buffer[i * 2 + 1] = (byte) ((pcm >> 8) & 255);
                            }
                            int written = track.write(buffer, 0, buffer.length);
                            if (written < 0) break;
                        }
                    } catch (Exception ignored) {
                    } finally {
                        if (track != null) {
                            try { track.pause(); } catch (Exception ignored) {}
                            try { track.flush(); } catch (Exception ignored) {}
                            try { track.release(); } catch (Exception ignored) {}
                        }
                        if (ambientAudioTrack == track) ambientAudioTrack = null;
                        ambientRunning = false;
                    }
                }
            }, "ColorSort-Gentle-Rain");
            ambientThread.setDaemon(true);
            ambientThread.start();
        }

        private synchronized void stopAmbientMusic() {
            ambientRunning = false;
            AudioTrack track = ambientAudioTrack;
            ambientAudioTrack = null;
            if (track != null) {
                try { track.pause(); } catch (Exception ignored) {}
                try { track.flush(); } catch (Exception ignored) {}
                try { track.release(); } catch (Exception ignored) {}
            }
        }

        /* =========================================================
           SAVE
           ========================================================= */

        private void saveProgress() {

            progressPrefs.edit()
                    .putInt("level", level)
                    .putInt("coins", coins)
                    .putInt("stars", totalStars)
                    .putBoolean("sound", soundEnabled)
                    .apply();
        }

        /* =========================================================
           LEVEL RESET
           ========================================================= */

        void resetLevel() {

            selectedTube = -1;

            moves = 0;

            mistakes = 0;

            levelFinished = false;

            levelFailed = false;

            animFrom = -1;
            animTo = -1;
            animColor = -1;
            animAmount = 0;

            animProgress = 1f;

            victoryStart = 0L;
            failureStart = 0L;

            errorFrom = -1;
            errorTo = -1;
            errorStart = 0L;

            tubes.clear();
            history.clear();

            int count = getColorCount();

            for (int c = 0; c < count; c++) {

                List<Integer> tube =
                        new ArrayList<>();

                for (int i = 0; i < CAPACITY; i++) {
                    tube.add(c);
                }

                tubes.add(tube);
            }

            int empty =
                    level < 18
                            ? 2
                            : (level < 38 ? 3 : 4);

            for (int i = 0; i < empty; i++) {
                tubes.add(new ArrayList<Integer>());
            }

            shufflePuzzle(getShuffleCount());

            invalidate();
        }

        private int getColorCount() {

            if (level <= 2) return 3;
            if (level <= 5) return 4;
            if (level <= 9) return 5;
            if (level <= 13) return 6;
            if (level <= 18) return 7;
            if (level <= 24) return 8;
            if (level <= 30) return 9;
            if (level <= 36) return 10;
            if (level <= 43) return 11;

            return 12;
        }

        private int getShuffleCount() {

            if (level <= 2) {
                return 18 + level * 5;
            }

            if (level <= 10) {
                return 35 + level * 5;
            }

            if (level <= 20) {
                return 75 + level * 5;
            }

            if (level <= 35) {
                return 125 + level * 6;
            }

            return 170 + level * 7;
        }

        /* =========================================================
           PUZZLE SHUFFLE
           ========================================================= */

        private void shufflePuzzle(int count) {

            int previousFrom = -1;
            int previousTo = -1;

            for (int step = 0; step < count; step++) {

                List<Integer> froms =
                        new ArrayList<>();

                for (int i = 0; i < tubes.size(); i++) {

                    if (!tubes.get(i).isEmpty()) {
                        froms.add(i);
                    }
                }

                Collections.shuffle(
                        froms,
                        random
                );

                boolean moved = false;

                for (int from : froms) {

                    if (from == previousTo) {
                        continue;
                    }

                    List<Integer> source =
                            tubes.get(from);

                    if (source.isEmpty()) {
                        continue;
                    }

                    int sourceColor =
                            source.get(
                                    source.size() - 1
                            );

                    int same =
                            getTopSameCount(source);

                    List<Integer> targets =
                            new ArrayList<>();

                    for (int to = 0;
                         to < tubes.size();
                         to++) {

                        if (to == from ||
                                to == previousFrom) {
                            continue;
                        }

                        List<Integer> target =
                                tubes.get(to);

                        if (target.size() >= CAPACITY) {
                            continue;
                        }

                        if (target.isEmpty() ||
                                target.get(
                                        target.size() - 1
                                ) != sourceColor) {

                            targets.add(to);
                        }
                    }

                    if (targets.isEmpty()) {
                        continue;
                    }

                    Collections.shuffle(
                            targets,
                            random
                    );

                    int to =
                            targets.get(0);

                    List<Integer> target =
                            tubes.get(to);

                    int free =
                            CAPACITY -
                                    target.size();

                    int amount =
                            Math.min(
                                    same,
                                    Math.min(
                                            free,
                                            1 + random.nextInt(2)
                                    )
                            );

                    for (int n = 0;
                         n < amount;
                         n++) {

                        target.add(
                                source.remove(
                                        source.size() - 1
                                )
                        );
                    }

                    previousFrom = from;
                    previousTo = to;

                    moved = true;

                    break;
                }

                if (!moved) {
                    break;
                }
            }

            if (isLevelComplete() &&
                    count < 120) {

                shufflePuzzle(count + 15);
            }
        }

        private int getTopSameCount(
                List<Integer> tube
        ) {

            if (tube.isEmpty()) {
                return 0;
            }

            int color =
                    tube.get(
                            tube.size() - 1
                    );

            int count = 0;

            for (int i = tube.size() - 1;
                 i >= 0;
                 i--) {

                if (tube.get(i) == color) {
                    count++;
                } else {
                    break;
                }
            }

            return count;
        }

        /* =========================================================
           DRAW
           ========================================================= */

        @Override
        protected void onDraw(Canvas canvas) {

            super.onDraw(canvas);

            float w = getWidth();
            float h = getHeight();

            drawBackground(
                    canvas,
                    w,
                    h
            );

            drawHeader(
                    canvas,
                    w
            );

            drawShelvesAndTubes(
                    canvas,
                    w,
                    h
            );

            drawControls(
                    canvas,
                    w,
                    h
            );

            drawFooter(
                    canvas,
                    w,
                    h
            );

            if (errorStart > 0 &&
                    SystemClock.uptimeMillis()
                            - errorStart
                            < 650) {

                drawErrorMark(
                        canvas,
                        w,
                        h
                );
            }

            if (levelFinished) {

                drawVictory(
                        canvas,
                        w,
                        h
                );
            }

            if (levelFailed) {

                drawFailure(
                        canvas,
                        w,
                        h
                );
            }

            if (animProgress < 1f) {

                long elapsed =
                        SystemClock.uptimeMillis()
                                - animStart;

                animProgress =
                        Math.min(
                                1f,
                                elapsed / 820f
                        );

                if (animProgress >= 1f) {
                    finishAnimatedMove();
                }

                invalidate();
            }
        }

        /* =========================================================
           BACKGROUND
           ========================================================= */

        private void drawBackground(
                Canvas c,
                float w,
                float h
        ) {
            // A quiet, distant midnight sky: deep navy rather than a bright fantasy glow.
            p.setShader(new LinearGradient(
                    0, 0, 0, h,
                    Color.rgb(10, 18, 43),
                    Color.rgb(17, 20, 55),
                    Shader.TileMode.CLAMP
            ));
            c.drawRect(0, 0, w, h, p);
            p.setShader(null);

            // Very restrained atmospheric haze, kept behind the puzzle area.
            float drift = liquidWave * 0.006f;
            float hazeX = w * (0.48f + 0.025f * (float) Math.sin(drift));
            float hazeY = h * 0.42f;
            RadialGradient haze = new RadialGradient(
                    hazeX, hazeY, w * 0.72f,
                    new int[]{Color.argb(25, 76, 93, 155),
                            Color.argb(12, 58, 73, 132), Color.TRANSPARENT},
                    new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP
            );
            p.setShader(haze);
            c.drawCircle(hazeX, hazeY, w * 0.72f, p);
            p.setShader(null);

            // A soft bank of distant blue clouds, inspired by the supplied moonlit reference.
            // Kept translucent so the bottles and controls remain easy to see.
            float cloudLine = h * 0.635f;
            p.setShader(new RadialGradient(
                    w * 0.34f, cloudLine, w * 0.48f,
                    new int[]{Color.argb(34, 76, 126, 220),
                            Color.argb(18, 43, 91, 177), Color.TRANSPARENT},
                    new float[]{0f, 0.58f, 1f}, Shader.TileMode.CLAMP
            ));
            c.drawOval(new RectF(-w * 0.12f, cloudLine - h * 0.045f,
                    w * 0.72f, cloudLine + h * 0.12f), p);
            p.setShader(null);
            p.setColor(Color.argb(17, 107, 153, 225));
            c.drawOval(new RectF(w * 0.48f, cloudLine - h * 0.025f,
                    w * 1.12f, cloudLine + h * 0.105f), p);

            // Brighter silver crescent moon with a wider, gentle blue-white halo.
            float moonX = w * 0.82f;
            float moonY = h * 0.155f;
            float moonRadius = Math.max(20f, Math.min(31f, w * 0.052f));
            float moonPulse = 0.94f + 0.06f * (float) Math.sin(liquidWave * 0.018f);
            RadialGradient moonHalo = new RadialGradient(
                    moonX, moonY, moonRadius * 4.8f,
                    new int[]{Color.argb(92, 184, 211, 255),
                            Color.argb(35, 136, 174, 245), Color.TRANSPARENT},
                    new float[]{0f, 0.42f, 1f}, Shader.TileMode.CLAMP
            );
            p.setShader(moonHalo);
            c.drawCircle(moonX, moonY, moonRadius * 4.8f, p);
            p.setShader(null);

            Path crescent = new Path();
            crescent.moveTo(moonX + moonRadius * 0.34f, moonY - moonRadius);
            crescent.cubicTo(moonX - moonRadius * 1.12f, moonY - moonRadius * 0.82f,
                    moonX - moonRadius * 1.22f, moonY + moonRadius * 0.78f,
                    moonX + moonRadius * 0.34f, moonY + moonRadius);
            crescent.cubicTo(moonX - moonRadius * 0.18f, moonY + moonRadius * 0.48f,
                    moonX - moonRadius * 0.18f, moonY - moonRadius * 0.48f,
                    moonX + moonRadius * 0.34f, moonY - moonRadius);
            crescent.close();
            p.setShader(new LinearGradient(moonX - moonRadius, moonY - moonRadius,
                    moonX + moonRadius, moonY + moonRadius,
                    Color.rgb(255, 255, 255), Color.rgb(164, 203, 255), Shader.TileMode.CLAMP));
            p.setAlpha((int) (255f * moonPulse));
            p.setShadowLayer(15f, 0f, 0f, Color.rgb(153, 199, 255));
            c.drawPath(crescent, p);
            p.clearShadowLayer();
            p.setAlpha(255);
            p.setShader(null);

            // More visible stars with slow, soft twinkling and a few delicate starbursts.
            for (int i = 0; i < 145; i++) {
                float phase = liquidWave * 0.012f + i * 1.713f;
                float x = (i * 127.7f + 31f) % Math.max(1f, w);
                float y = 18f + ((i * 173.3f) % Math.max(1f, h - 36f));
                float twinkle = 0.5f + 0.5f * (float) Math.sin(phase);
                int alpha = 75 + (int) (125f * twinkle);
                float radius = 0.9f + (i % 4) * 0.43f;
                p.setColor(Color.argb(alpha, 205, 222, 255));
                c.drawCircle(x, y, radius, p);

                if (i % 9 == 0) {
                    p.setColor(Color.argb(38 + (int) (65f * twinkle), 220, 235, 255));
                    c.drawCircle(x, y, radius * 3.2f, p);
                }
                if (i % 29 == 0) {
                    stroke.setStyle(Paint.Style.STROKE);
                    stroke.setStrokeWidth(1.0f);
                    stroke.setColor(Color.argb(65 + (int) (90f * twinkle), 220, 235, 255));
                    c.drawLine(x - radius * 3.5f, y, x + radius * 3.5f, y, stroke);
                    c.drawLine(x, y - radius * 3.5f, x, y + radius * 3.5f, stroke);
                }
            }

            // Fine, slow rain in the distant sky: decorative only, never obscures the puzzle.
            for (int i = 0; i < 34; i++) {
                float speed = 0.34f + (i % 5) * 0.075f;
                float x = (i * 83.7f + (float) Math.sin(liquidWave * 0.018f + i) * 7f)
                        % Math.max(1f, w);
                float span = Math.max(1f, h * 0.72f);
                float y = h * 0.08f + ((i * 61.3f + liquidWave * speed) % span);
                p.setColor(Color.argb(18 + (i % 4) * 4, 174, 202, 235));
                p.setStrokeWidth(0.8f);
                c.drawLine(x, y, x - 2.2f, y + 7.5f, p);
            }

            // Sparse, slow-moving distant dust; deliberately dim and unobtrusive.
            for (int i = 0; i < 12; i++) {
                float phase = drift + i * 0.91f;
                float x = (i * 91f + (float) Math.sin(phase) * 13f) % Math.max(1f, w);
                float y = h * 0.16f + ((i * 137f + liquidWave * (0.22f + (i % 3) * 0.08f))
                        % (h * 0.70f));
                p.setColor(Color.argb(13 + (int) (9f * (0.5f + 0.5f * Math.sin(phase))),
                        174, 190, 225));
                c.drawCircle(x, y, 1.0f + (i % 2) * 0.35f, p);
            }
        }

        /* =========================================================
           HEADER
           ========================================================= */

        private void drawHeader(
                Canvas c,
                float w
        ) {

            float y = 12;

            float margin = 12;

            float homeRight = 78;

            drawRoundPanel(
                    c,
                    margin,
                    y,
                    homeRight,
                    78,
                    Color.rgb(0, 166, 255),
                    Color.rgb(48, 78, 255)
            );

            text.setTypeface(
                    Typeface.DEFAULT_BOLD
            );

            text.setTextAlign(
                    Paint.Align.CENTER
            );

            text.setTextSize(36);

            text.setColor(Color.WHITE);

            c.drawText(
                    "⌂",
                    (margin + homeRight) / 2f,
                    59,
                    text
            );

            float coinWidth = 105;

            float coinLeft =
                    Math.max(
                            homeRight + 8,
                            w - coinWidth - margin
                    );

            float stageLeft =
                    homeRight + 8;

            float stageRight =
                    Math.min(
                            coinLeft - 8,
                            stageLeft + 175
                    );

            if (stageRight <= stageLeft) {
                stageRight = stageLeft + 130;
            }

            drawRoundPanel(
                    c,
                    stageLeft,
                    y,
                    stageRight,
                    78,
                    Color.rgb(111, 26, 238),
                    Color.rgb(190, 37, 255)
            );

            text.setTextSize(16);
            text.setColor(Color.WHITE);

            c.drawText(
                    "★  " + tr("مرحله ", "Level ", "مرحله ", "مرحلہ ", "स्तर ", "المرحلة ") + level,
                    (stageLeft + stageRight) / 2f,
                    59,
                    text
            );

            float starsLeft =
                    stageRight + 8;

            float starsRight =
                    coinLeft - 8;

            if (starsRight > starsLeft + 40) {

                drawRoundPanel(
                        c,
                        starsLeft,
                        y,
                        starsRight,
                        78,
                        Color.rgb(30, 20, 130),
                        Color.rgb(117, 39, 250)
                );

                float center =
                        (starsLeft + starsRight) / 2f;

                drawStar(
                        c,
                        center - 28,
                        39,
                        14,
                        Color.rgb(255, 208, 25)
                );

                drawStar(
                        c,
                        center,
                        39,
                        14,
                        Color.rgb(255, 208, 25)
                );

                drawStar(
                        c,
                        center + 28,
                        39,
                        14,
                        Color.rgb(255, 208, 25)
                );

                p.setColor(
                        Color.rgb(
                                255,
                                207,
                                25
                        )
                );

                c.drawRoundRect(
                        new RectF(
                                starsLeft + 15,
                                61,
                                starsRight - 15,
                                67
                        ),
                        4,
                        4,
                        p
                );
            }

            drawRoundPanel(
                    c,
                    coinLeft,
                    y,
                    w - margin,
                    78,
                    Color.rgb(9, 84, 235),
                    Color.rgb(35, 205, 255)
            );

            drawCoin(
                    c,
                    coinLeft + 25,
                    45
            );

            text.setTextSize(15);
            text.setColor(Color.WHITE);
            text.setTextAlign(Paint.Align.LEFT);

            c.drawText(
                    String.valueOf(coins),
                    coinLeft + 47,
                    52,
                    text
            );

            // No shop is connected yet; keep the coin counter informational.
        }

        /* =========================================================
           SHELVES / TUBES
           ========================================================= */

        private void drawShelvesAndTubes(
                Canvas c,
                float w,
                float h
        ) {

            int count =
                    tubes.size();

            int columns =
                    count <= 6 ? 3 : 5;

            int rows =
                    (int) Math.ceil(
                            count /
                                    (float) columns
                    );

            float top = 116;

            float bottomControls = 275;

            float areaH =
                    Math.max(
                            300,
                            h - top - bottomControls
                    );

            float rowH =
                    areaH /
                            Math.max(
                                    1,
                                    rows
                            );

            float tubeW =
                    Math.min(
                            92,
                            w / (columns + .9f)
                    );

            float tubeH =
                    Math.min(
                            230,
                            rowH * .76f
                    );

            for (int row = 0;
                 row < rows;
                 row++) {

                float shelfY =
                        top +
                                row * rowH +
                                rowH * .83f;

                drawShelf(
                        c,
                        20,
                        shelfY,
                        w - 20,
                        22
                );

                for (int col = 0;
                     col < columns;
                     col++) {

                    int index =
                            row * columns + col;

                    if (index >= count) {
                        break;
                    }

                    float cx =
                            w *
                                    (col + 1f)
                                    /
                                    (columns + 1f);

                    float cy =
                            top +
                                    row * rowH +
                                    rowH * .42f;

                    drawTube(
                            c,
                            index,
                            cx,
                            cy,
                            tubeW,
                            tubeH
                    );
                }
            }
        }

        private void drawShelf(
                Canvas c,
                float left,
                float y,
                float right,
                float height
        ) {

            p.setStyle(Paint.Style.FILL);

            p.setShadowLayer(
                    12,
                    0,
                    8,
                    Color.argb(
                            160,
                            0,
                            0,
                            0
                    )
            );

            p.setShader(
                    new LinearGradient(
                            0,
                            y,
                            0,
                            y + height,
                            Color.rgb(
                                    255,
                                    184,
                                    76
                            ),
                            Color.rgb(
                                    130,
                                    59,
                                    20
                            ),
                            Shader.TileMode.CLAMP
                    )
            );

            c.drawRoundRect(
                    new RectF(
                            left,
                            y,
                            right,
                            y + height
                    ),
                    12,
                    12,
                    p
            );

            p.setShader(null);

            p.clearShadowLayer();

            stroke.setStyle(
                    Paint.Style.STROKE
            );

            stroke.setStrokeWidth(2);

            stroke.setColor(
                    Color.argb(
                            180,
                            255,
                            225,
                            130
                    )
            );

            c.drawRoundRect(
                    new RectF(
                            left,
                            y,
                            right,
                            y + height
                    ),
                    12,
                    12,
                    stroke
            );
        }

        /* =========================================================
           TUBE
           ========================================================= */

        private void drawTube(
                Canvas c,
                int index,
                float cx,
                float cy,
                float tw,
                float th
        ) {

            float left =
                    cx - tw / 2f;

            float right =
                    cx + tw / 2f;

            float top =
                    cy - th / 2f;

            float bottom =
                    cy + th / 2f;

            boolean selected =
                    index == selectedTube;

            boolean pouring =
                    animProgress < 1f &&
                            index == animFrom;

            boolean receiving =
                    animProgress < 1f &&
                            index == animTo;

            List<Integer> tube =
                    tubes.get(index);

            boolean shaking =
                    isTubeShaking(index);

            float shakeX =
                    shaking
                            ? getShakeOffset()
                            : 0f;

            float shakeAngle =
                    shaking
                            ? getShakeAngle()
                            : 0f;

            cx += shakeX;
            left += shakeX;
            right += shakeX;

            if (selected ||
                    pouring ||
                    isTubeComplete(tube)) {

                int glowColor =
                        isTubeComplete(tube)
                                ? Color.rgb(
                                255,
                                213,
                                70
                        )
                                : Color.rgb(
                                50,
                                225,
                                255
                        );

                p.setStyle(
                        Paint.Style.FILL
                );

                p.setColor(
                        Color.argb(
                                selected ? 80 : 42,
                                Color.red(glowColor),
                                Color.green(glowColor),
                                Color.blue(glowColor)
                        )
                );

                p.setShadowLayer(
                        selected ? 28 : 18,
                        0,
                        4,
                        glowColor
                );

                c.drawRoundRect(
                        new RectF(
                                left - 8,
                                top - 8,
                                right + 8,
                                bottom + 8
                        ),
                        28,
                        28,
                        p
                );

                p.clearShadowLayer();
            }

            float angle = 0f;

            if (pouring) {

                float[] target =
                        getTubeGeometry(animTo);

                float direction =
                        target[0] >= cx
                                ? 1f
                                : -1f;

                float wave =
                        (float) Math.sin(
                                animProgress *
                                        Math.PI
                        );

                angle =
                        direction *
                                24f *
                                wave;
            }

            angle += shakeAngle;

            c.save();

            c.rotate(
                    angle,
                    cx,
                    bottom - 18
            );

            p.setStyle(
                    Paint.Style.FILL
            );

            p.setColor(
                    Color.argb(
                            65,
                            0,
                            0,
                            0
                    )
            );

            p.setShadowLayer(
                    16,
                    0,
                    10,
                    Color.argb(
                            180,
                            0,
                            0,
                            0
                    )
            );

            c.drawRoundRect(
                    new RectF(
                            left - 2,
                            top + 13,
                            right + 2,
                            bottom + 2
                    ),
                    25,
                    25,
                    p
            );

            p.clearShadowLayer();

            float neckTop =
                    top - 1;

            float neckBottom =
                    top + 28;

            float neckL =
                    left + 11;

            float neckR =
                    right - 11;

            Path bottlePath =
                    createBottlePath(
                            left,
                            right,
                            top + 12,
                            bottom,
                            neckL,
                            neckR,
                            neckTop,
                            neckBottom
                    );

            Path innerBottlePath =
                    createBottlePath(
                            left + 4,
                            right - 4,
                            top + 18,
                            bottom - 5,
                            neckL + 2,
                            neckR - 2,
                            neckTop + 5,
                            neckBottom - 2
                    );

            p.setShader(
                    new LinearGradient(
                            left,
                            top,
                            right,
                            bottom,
                            Color.argb(
                                    135,
                                    255,
                                    255,
                                    255
                            ),
                            Color.argb(
                                    18,
                                    78,
                                    165,
                                    255
                            ),
                            Shader.TileMode.CLAMP
                    )
            );

            c.drawPath(
                    bottlePath,
                    p
            );

            p.setShader(null);

            p.setShader(
                    new LinearGradient(
                            left,
                            top,
                            right,
                            bottom,
                            Color.argb(
                                    32,
                                    190,
                                    235,
                                    255
                            ),
                            Color.argb(
                                    58,
                                    20,
                                    85,
                                    180
                            ),
                            Shader.TileMode.CLAMP
                    )
            );

            c.drawPath(
                    innerBottlePath,
                    p
            );

            p.setShader(null);

            /* Neck */

            p.setStyle(
                    Paint.Style.FILL
            );

            p.setColor(
                    Color.argb(
                            52,
                            255,
                            255,
                            255
                    )
            );

            c.drawRoundRect(
                    new RectF(
                            neckL,
                            neckTop + 5,
                            neckR,
                            neckBottom
                    ),
                    10,
                    10,
                    p
            );

            stroke.setStyle(
                    Paint.Style.STROKE
            );

            stroke.setStrokeWidth(2.6f);

            stroke.setColor(
                    Color.argb(
                            235,
                            224,
                            250,
                            255
                    )
            );

            c.drawRoundRect(
                    new RectF(
                            neckL,
                            neckTop,
                            neckR,
                            neckBottom
                    ),
                    10,
                    10,
                    stroke
            );

            float innerL =
                    left + 8;

            float innerR =
                    right - 8;

            float innerB =
                    bottom - 8;

            float layerH =
                    (bottom - top - 30)
                            / CAPACITY;

            float visibleUnits =
                    pouring
                            ? Math.max(
                            0f,
                            tube.size()
                                    -
                                    animAmount *
                                            animProgress
                    )
                            : tube.size();

            c.save();

            c.clipPath(
                    innerBottlePath
            );

            for (int j = 0;
                 j < tube.size();
                 j++) {

                float visible =
                        Math.max(
                                0f,
                                Math.min(
                                        1f,
                                        visibleUnits - j
                                )
                        );

                if (visible <= 0f) {
                    continue;
                }

                float lb =
                        innerB -
                                j * layerH;

                float lt =
                        lb -
                                layerH *
                                        visible;

                drawLiquid(
                        c,
                        innerL,
                        lt,
                        innerR,
                        lb,
                        tube.get(j),
                        Math.abs(
                                (j + 1)
                                        -
                                        visibleUnits
                        ) < .06f
                );
            }

            if (receiving &&
                    animColor >= 0) {

                float incoming =
                        animAmount *
                                animProgress;

                float lb =
                        innerB -
                                tube.size() *
                                        layerH;

                float lt =
                        lb -
                                incoming *
                                        layerH;

                if (incoming > 0f) {

                    drawLiquid(
                            c,
                            innerL,
                            lt,
                            innerR,
                            lb,
                            animColor,
                            true
                    );
                }
            }

            c.restore();

            if (pouring) {

                drawPourStream(
                        c,
                        cx,
                        top + 16,
                        animTo,
                        animColor,
                        animProgress,
                        angle
                );
            }

            /* Reflection */

            p.setShader(
                    new LinearGradient(
                            left + 7,
                            0,
                            left + 28,
                            0,
                            Color.argb(
                                    145,
                                    255,
                                    255,
                                    255
                            ),
                            Color.argb(
                                    0,
                                    255,
                                    255,
                                    255
                            ),
                            Shader.TileMode.CLAMP
                    )
            );

            c.drawRoundRect(
                    new RectF(
                            left + 7,
                            top + 22,
                            left + 27,
                            bottom - 14
                    ),
                    9,
                    9,
                    p
            );

            p.setShader(null);

            p.setColor(
                    Color.argb(
                            125,
                            255,
                            255,
                            255
                    )
            );

            c.drawRoundRect(
                    new RectF(
                            left + 13,
                            top + 16,
                            right - 18,
                            top + 20
                    ),
                    3,
                    3,
                    p
            );

            // Layered glass bevels: cool edge refraction and narrow specular highlights.
            p.setStyle(Paint.Style.STROKE);
            p.setShader(null);
            p.setStrokeWidth(Math.max(1.2f, tw * 0.035f));
            p.setColor(Color.argb(92, 126, 207, 255));
            c.drawPath(bottlePath, p);

            // A pair of slim highlights makes the curved glass read as thick crystal.
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeCap(Paint.Cap.ROUND);
            stroke.setStrokeWidth(Math.max(1.5f, tw * 0.045f));
            stroke.setColor(Color.argb(150, 245, 252, 255));
            c.drawLine(left + 5.5f, top + 43f, left + 5.5f,
                    bottom - 31f, stroke);
            stroke.setStrokeWidth(Math.max(1.0f, tw * 0.022f));
            stroke.setColor(Color.argb(82, 188, 229, 255));
            c.drawLine(right - 5.5f, top + 48f, right - 5.5f,
                    bottom - 34f, stroke);

            // Soft curved reflection near the heavy glass base.
            stroke.setStrokeWidth(Math.max(1.2f, tw * 0.032f));
            stroke.setColor(Color.argb(105, 232, 248, 255));
            c.drawArc(new RectF(left + 8f, bottom - 17f,
                    right - 8f, bottom + 1f), 12f, 156f, false, stroke);

            // Double rim around the mouth gives the opening a rounded glass lip.
            stroke.setStrokeWidth(Math.max(1.4f, tw * 0.04f));
            stroke.setColor(Color.argb(205, 239, 250, 255));
            c.drawRoundRect(new RectF(neckL - 1.5f, neckTop - 1.5f,
                    neckR + 1.5f, neckTop + 7f), 8f, 8f, stroke);
            stroke.setStrokeWidth(1.0f);
            stroke.setColor(Color.argb(105, 115, 190, 235));
            c.drawRoundRect(new RectF(neckL + 3f, neckTop + 3f,
                    neckR - 3f, neckTop + 10f), 5f, 5f, stroke);

            stroke.setStyle(
                    Paint.Style.STROKE
            );

            stroke.setStrokeWidth(
                    selected ? 4.2f : 2.7f
            );

            stroke.setColor(
                    selected
                            ? Color.rgb(
                            83,
                            244,
                            255
                    )
                            : Color.argb(
                            238,
                            225,
                            250,
                            255
                    )
            );

            c.drawPath(
                    bottlePath,
                    stroke
            );

            stroke.setStrokeWidth(2.2f);

            c.drawArc(
                    new RectF(
                            left + 4,
                            bottom - 19,
                            right - 4,
                            bottom + 5
                    ),
                    0,
                    180,
                    false,
                    stroke
            );

            stroke.setStrokeWidth(3f);

            c.drawRoundRect(
                    new RectF(
                            left + 3,
                            top,
                            right - 3,
                            top + 27
                    ),
                    11,
                    11,
                    stroke
            );

            stroke.setStrokeWidth(1.4f);

            stroke.setColor(
                    Color.argb(
                            180,
                            255,
                            255,
                            255
                    )
            );

            c.drawRoundRect(
                    new RectF(
                            left + 7,
                            top + 5,
                            right - 7,
                            top + 18
                    ),
                    7,
                    7,
                    stroke
            );

            c.restore();

            if (isTubeComplete(tube)) {

                drawCap(
                        c,
                        cx,
                        top + 1,
                        tw
                );
            }

            drawBadge(
                    c,
                    cx,
                    bottom + 11,
                    String.valueOf(index + 1),
                    selected
            );
        }

        /* =========================================================
           SHAKE
           ========================================================= */

        private boolean isTubeShaking(int index) {

            if (errorStart <= 0) {
                return false;
            }

            long elapsed =
                    SystemClock.uptimeMillis()
                            - errorStart;

            if (elapsed > 650) {
                return false;
            }

            return index == errorFrom ||
                    index == errorTo;
        }

        private float getShakeOffset() {

            long elapsed =
                    SystemClock.uptimeMillis()
                            - errorStart;

            float progress =
                    Math.min(
                            1f,
                            elapsed / 650f
                    );

            float strength =
                    errorStrength >= 2
                            ? 13f
                            : 8f;

            float envelope =
                    1f - progress;

            return (float)
                    Math.sin(
                            progress *
                                    Math.PI *
                                    9f
                    )
                            *
                            strength
                            *
                            envelope;
        }

        private float getShakeAngle() {

            long elapsed =
                    SystemClock.uptimeMillis()
                            - errorStart;

            float progress =
                    Math.min(
                            1f,
                            elapsed / 650f
                    );

            float strength =
                    errorStrength >= 2
                            ? 6f
                            : 3.5f;

            float envelope =
                    1f - progress;

            return (float)
                    Math.sin(
                            progress *
                                    Math.PI *
                                    8f
                    )
                            *
                            strength
                            *
                            envelope;
        }

        /* =========================================================
           POUR STREAM
           ========================================================= */

        private void drawPourStream(
                Canvas c,
                float sx,
                float sy,
                int targetIndex,
                int colorIndex,
                float progress,
                float angle
        ) {

            if (targetIndex < 0 ||
                    colorIndex < 0 ||
                    colorIndex >= colors.length) {
                return;
            }

            float[] target = getTubeGeometry(targetIndex);
            if (target == null) return;

            float tx = target[0];
            float ty = target[1] - target[3] / 2f + 37f;

            float eased = progress * progress * (3f - 2f * progress);
            float startX = sx + (float) Math.sin(Math.toRadians(angle)) * 16f;
            float startY = sy + 8f;

            // The stream grows from the neck, bends naturally toward the target,
            // then becomes narrower as the pour finishes.
            float reach = Math.min(1f, progress * 1.22f);
            float endX = startX + (tx - startX) * reach;
            float endY = startY + (ty - startY) * Math.min(1f, eased * 1.12f);

            float dir = tx >= startX ? 1f : -1f;
            float curve = dir * Math.min(34f, Math.abs(tx - startX) * .16f);
            float wave = (float) Math.sin(liquidWave * 2.2f) * 4f;

            float bx = (startX + endX) * .5f + curve;
            float by = (startY + endY) * .5f + 10f + wave;

            int base = getLevelAdjustedColor(colorIndex);
            int light = lighten(base, 1.55f);
            int dark = darken(base, .38f);

            float thickness =
                    4.2f +
                            2.4f * (float) Math.sin(progress * Math.PI);

            Path stream = new Path();
            stream.moveTo(startX - thickness, startY);
            stream.cubicTo(
                    startX - thickness * .7f,
                    startY + 20f,
                    bx - thickness,
                    by,
                    endX - thickness * .55f,
                    endY
            );
            stream.lineTo(endX + thickness * .55f, endY);
            stream.cubicTo(
                    bx + thickness,
                    by,
                    startX + thickness * .7f,
                    startY + 20f,
                    startX + thickness,
                    startY
            );
            stream.close();

            p.setShader(new LinearGradient(
                    startX, 0,
                    endX, 0,
                    light,
                    dark,
                    Shader.TileMode.CLAMP
            ));
            p.setShadowLayer(11, 0, 3, base);
            c.drawPath(stream, p);
            p.clearShadowLayer();
            p.setShader(null);

            // Moving white reflection down the stream.
            float highlightQ = (liquidWave * .055f) % 1f;
            float hx = startX + (endX - startX) * highlightQ;
            float hy = startY + (endY - startY) * highlightQ;
            p.setColor(Color.argb(145, 255, 255, 255));
            c.drawCircle(hx, hy, Math.max(1.1f, thickness * .23f), p);

            // Falling droplets around the main stream.
            int drops = 5 + (int) (progress * 5f);
            for (int i = 0; i < drops; i++) {
                float q = (i + 1f) / (drops + 1f);
                float dx = startX + (endX - startX) * q;
                float dy = startY + (endY - startY) * q;
                float sway = (float) Math.sin(liquidWave * 2.7f + i * 1.9f) * (2f + q * 3f);
                float radius = 1.2f + (i % 3) * .55f;

                p.setColor(Color.argb(
                        175,
                        Color.red(light),
                        Color.green(light),
                        Color.blue(light)
                ));
                c.drawCircle(dx + sway, dy, radius, p);
            }

            // Splash at the receiving bottle.
            float splash = (float) Math.sin(progress * Math.PI);
            if (splash > .03f) {
                stroke.setStyle(Paint.Style.STROKE);
                stroke.setStrokeWidth(1.8f + splash * 1.2f);
                stroke.setColor(Color.argb((int) (205 * splash), 255, 255, 255));

                float radius = 7f + 13f * splash;
                c.drawOval(
                        new RectF(
                                endX - radius,
                                endY - 3f,
                                endX + radius,
                                endY + 4f
                        ),
                        stroke
                );

                // Two tiny splash drops.
                p.setColor(Color.argb((int) (180 * splash),
                        Color.red(light), Color.green(light), Color.blue(light)));
                c.drawCircle(endX - radius * .65f, endY - 5f - splash * 5f, 1.8f, p);
                c.drawCircle(endX + radius * .65f, endY - 4f - splash * 4f, 1.6f, p);
            }
        }

        /* =========================================================
           BOTTLE PATH
           ========================================================= */

        private Path createBottlePath(
                float left,
                float right,
                float bodyTop,
                float bottom,
                float neckL,
                float neckR,
                float neckTop,
                float neckBottom
        ) {

            Path path =
                    new Path();

            float shoulder =
                    bodyTop + 24f;

            path.moveTo(
                    neckL,
                    neckTop
            );

            path.lineTo(
                    neckL,
                    neckBottom
            );

            path.cubicTo(
                    neckL,
                    shoulder - 4,
                    left + 3,
                    shoulder - 1,
                    left + 2,
                    shoulder + 18
            );

            path.lineTo(
                    left + 2,
                    bottom - 28
            );

            path.cubicTo(
                    left + 2,
                    bottom - 9,
                    left + 13,
                    bottom,
                    (left + right) / 2f,
                    bottom
            );

            path.cubicTo(
                    right - 13,
                    bottom,
                    right - 2,
                    bottom - 9,
                    right - 2,
                    bottom - 28
            );

            path.lineTo(
                    right - 2,
                    shoulder + 18
            );

            path.cubicTo(
                    right - 3,
                    shoulder - 1,
                    neckR,
                    shoulder - 4,
                    neckR,
                    neckBottom
            );

            path.lineTo(
                    neckR,
                    neckTop
            );

            path.close();

            return path;
        }

        /* =========================================================
           GEOMETRY
           ========================================================= */

        private float[] getTubeGeometry(
                int index
        ) {

            if (index < 0 ||
                    index >= tubes.size()) {

                return null;
            }

            int count =
                    tubes.size();

            int columns =
                    count <= 6 ? 3 : 5;

            int rows =
                    (int)
                            Math.ceil(
                                    count /
                                            (float)
                                                    columns
                            );

            float w =
                    getWidth();

            float h =
                    getHeight();

            float top = 116;

            float bottomControls = 275;

            float areaH =
                    Math.max(
                            300,
                            h -
                                    top -
                                    bottomControls
                    );

            float rowH =
                    areaH /
                            Math.max(
                                    1,
                                    rows
                            );

            float tubeW =
                    Math.min(
                            92,
                            w /
                                    (columns + .9f)
                    );

            float tubeH =
                    Math.min(
                            230,
                            rowH * .76f
                    );

            int row =
                    index / columns;

            int col =
                    index % columns;

            float cx =
                    w *
                            (col + 1f)
                            /
                            (columns + 1f);

            float cy =
                    top +
                            row * rowH +
                            rowH * .42f;

            return new float[]{
                    cx,
                    cy,
                    tubeW,
                    tubeH
            };
        }

        private int getLevelAdjustedColor(int colorIndex) {
            int base = colors[colorIndex];
            if (level <= 25) return base;
            Color.colorToHSV(base, colorHsvScratch);
            // A restrained advanced-stage tint helps distinguish close shades
            // while keeping each color recognizable and the sorting rules intact.
            float offset = 1.4f + ((level - 26) % 4) * 0.30f
                    + (colorIndex % 3) * 0.18f;
            colorHsvScratch[0] = (colorHsvScratch[0] + offset) % 360f;
            colorHsvScratch[1] = Math.min(1f, colorHsvScratch[1] * 1.012f);
            return Color.HSVToColor(Color.alpha(base), colorHsvScratch);
        }

        /* =========================================================
           LIQUID
           ========================================================= */

        private void drawLiquid(
                Canvas c,
                float left,
                float top,
                float right,
                float bottom,
                int colorIndex,
                boolean topLayer
        ) {

            if (colorIndex < 0 ||
                    colorIndex >= colors.length ||
                    bottom <= top) {
                return;
            }

            int base = getLevelAdjustedColor(colorIndex);
            int light = lighten(base, 1.55f);
            int mid = lighten(base, 1.08f);
            int dark = darken(base, .42f);

            float height = bottom - top;
            float radius = Math.min(11f, Math.max(4f, height * .24f));

            // Deep liquid body.
            p.setStyle(Paint.Style.FILL);
            p.setShader(new LinearGradient(
                    0, top,
                    0, bottom,
                    light,
                    dark,
                    Shader.TileMode.CLAMP
            ));
            c.drawRoundRect(
                    new RectF(left, top, right, bottom),
                    radius,
                    radius,
                    p
            );
            p.setShader(null);

            // Moving internal light band gives the liquid depth.
            float sweep =
                    (float) Math.sin(liquidWave * .72f + colorIndex * .8f);
            float shineLeft =
                    left + 7f +
                            (sweep + 1f) * Math.max(2f, (right - left - 30f) * .18f);

            p.setShader(new LinearGradient(
                    shineLeft, 0,
                    shineLeft + 24f, 0,
                    Color.argb(115, 255, 255, 255),
                    Color.argb(0, 255, 255, 255),
                    Shader.TileMode.CLAMP
            ));
            c.drawRoundRect(
                    new RectF(left + 2, top + 2, right - 2, bottom - 2),
                    radius,
                    radius,
                    p
            );
            p.setShader(null);

            // Soft vertical highlight.
            p.setColor(Color.argb(80, 255, 255, 255));
            c.drawRoundRect(
                    new RectF(left + 5, top + 4, left + 12, bottom - 4),
                    4,
                    4,
                    p
            );

            // Tiny moving bubbles. They are deterministic, so no allocations
            // or random flicker happen during the 60 FPS draw loop.
            int bubbleCount = height > 25f ? 4 : 2;
            for (int i = 0; i < bubbleCount; i++) {
                float seed = i * 2.17f + colorIndex * 1.31f;
                float q = (float) ((Math.sin(seed) + 1.0) * .5);
                float rise = (liquidWave * (0.7f + i * .08f) + seed * 5f) % 1f;
                float bx = left + 9f + q * Math.max(4f, right - left - 18f);
                float by = bottom - 6f - rise * Math.max(6f, height - 14f);
                float br = 1.3f + (i % 2) * .7f;

                p.setStyle(Paint.Style.FILL);
                p.setColor(Color.argb(48 + i * 10, 255, 255, 255));
                c.drawCircle(bx, by, br, p);
            }

            if (topLayer) {
                drawLiquidSurface(c, left, top, right, colorIndex);
            }
        }

        private void drawLiquidSurface(
                Canvas c,
                float left,
                float y,
                float right,
                int colorIndex
        ) {

            if (colorIndex < 0 || colorIndex >= colors.length) {
                return;
            }

            int base = getLevelAdjustedColor(colorIndex);
            int light = lighten(base, 1.60f);

            float width = right - left;
            float amp = Math.min(4.2f, Math.max(1.8f, width * .055f));

            // Two travelling waves make the surface look like liquid instead
            // of a flat colored rectangle.
            Path surface = new Path();
            surface.moveTo(left, y);

            for (int i = 0; i <= 24; i++) {
                float q = i / 24f;
                float x = left + width * q;
                float wave1 = (float) Math.sin(liquidWave * 1.25f + q * Math.PI * 2.4f);
                float wave2 = (float) Math.sin(liquidWave * 2.05f + q * Math.PI * 5.2f + .7f);
                float yy = y + wave1 * amp + wave2 * amp * .28f;
                surface.lineTo(x, yy);
            }

            surface.lineTo(right, y + 12f);
            surface.lineTo(left, y + 12f);
            surface.close();

            p.setShader(new LinearGradient(
                    0, y - 2f,
                    0, y + 15f,
                    light,
                    base,
                    Shader.TileMode.CLAMP
            ));
            c.drawPath(surface, p);
            p.setShader(null);

            // Moving bright crest.
            float crest =
                    left +
                            ((float) ((Math.sin(liquidWave * .55f) + 1f) * .5f))
                                    * Math.max(1f, width - 18f)
                                    + 6f;

            p.setColor(Color.argb(105, 255, 255, 255));
            c.drawOval(
                    new RectF(
                            crest - 17f,
                            y - 2f,
                            crest + 20f,
                            y + 5f
                    ),
                    p
            );

            // Thin reflective edge.
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeWidth(1.5f);
            stroke.setColor(Color.argb(175, 255, 255, 255));
            c.drawPath(surface, stroke);
        }

        /* =========================================================
           COMPLETE TUBE
           ========================================================= */

        private boolean isTubeComplete(
                List<Integer> tube
        ) {

            if (tube.size() != CAPACITY) {
                return false;
            }

            int color =
                    tube.get(0);

            for (int i = 1;
                 i < tube.size();
                 i++) {

                if (tube.get(i) != color) {
                    return false;
                }
            }

            return true;
        }

        /* =========================================================
           CAP
           ========================================================= */

        private void drawCap(
                Canvas c,
                float cx,
                float y,
                float tw
        ) {

            float capW =
                    tw * .58f;

            float capH = 27f;

            p.setStyle(
                    Paint.Style.FILL
            );

            p.setShader(
                    new LinearGradient(
                            0,
                            y,
                            0,
                            y + capH,
                            Color.rgb(
                                    255,
                                    222,
                                    132
                            ),
                            Color.rgb(
                                    139,
                                    69,
                                    18
                            ),
                            Shader.TileMode.CLAMP
                    )
            );

            p.setShadowLayer(
                    9,
                    0,
                    3,
                    Color.argb(
                            160,
                            0,
                            0,
                            0
                    )
            );

            c.drawRoundRect(
                    new RectF(
                            cx - capW / 2,
                            y,
                            cx + capW / 2,
                            y + capH
                    ),
                    8,
                    8,
                    p
            );

            p.clearShadowLayer();

            p.setShader(null);

            // Raised metallic crown and rolled lower rim give the cap depth.
            p.setShader(new LinearGradient(
                    cx - capW / 2f, y - 3f,
                    cx + capW / 2f, y + 5f,
                    Color.rgb(255, 248, 218),
                    Color.rgb(184, 119, 42),
                    Shader.TileMode.CLAMP
            ));
            c.drawOval(
                    new RectF(cx - capW / 2f, y - 4f,
                            cx + capW / 2f, y + 7f),
                    p
            );
            p.setShader(null);
            p.setColor(Color.argb(175, 255, 235, 174));
            c.drawRoundRect(
                    new RectF(cx - capW / 2f + 1f, y + capH - 5f,
                            cx + capW / 2f - 1f, y + capH),
                    3f, 3f, p
            );

            p.setColor(
                    Color.argb(
                            100,
                            96,
                            48,
                            15
                    )
            );

            for (int i = -3;
                 i <= 3;
                 i++) {

                float xx =
                        cx + i * 6;

                c.drawLine(
                        xx,
                        y + 4,
                        xx +
                                (i % 2) * 2,
                        y + capH - 4,
                        p
                );
            }

            p.setColor(
                    Color.argb(
                            100,
                            255,
                            244,
                            190
                    )
            );

            c.drawRoundRect(
                    new RectF(
                            cx - capW / 2 + 4,
                            y + 3,
                            cx + capW / 2 - 4,
                            y + 8
                    ),
                    4,
                    4,
                    p
            );

            stroke.setStyle(
                    Paint.Style.STROKE
            );

            stroke.setStrokeWidth(2.2f);

            stroke.setColor(
                    Color.rgb(
                            255,
                            239,
                            174
                    )
            );

            c.drawRoundRect(
                    new RectF(
                            cx - capW / 2,
                            y,
                            cx + capW / 2,
                            y + capH
                    ),
                    8,
                    8,
                    stroke
            );
        }

        /* =========================================================
           BADGE
           ========================================================= */

        private void drawBadge(
                Canvas c,
                float cx,
                float cy,
                String value,
                boolean selected
        ) {

            p.setColor(
                    selected
                            ? Color.rgb(
                            255,
                            197,
                            35
                    )
                            : Color.rgb(
                            16,
                            57,
                            160
                    )
            );

            c.drawRoundRect(
                    new RectF(
                            cx - 15,
                            cy - 13,
                            cx + 15,
                            cy + 13
                    ),
                    12,
                    12,
                    p
            );

            text.setTypeface(
                    Typeface.DEFAULT_BOLD
            );

            text.setTextAlign(
                    Paint.Align.CENTER
            );

            text.setTextSize(13);

            text.setColor(Color.WHITE);

            c.drawText(
                    value,
                    cx,
                    cy + 5,
                    text
            );
        }

        /* =========================================================
           CONTROLS
           ========================================================= */

        private void drawControls(
                Canvas c,
                float w,
                float h
        ) {

            float y =
                    h - 205;

            drawCircleButton(
                    c,
                    75,
                    y,
                    52,
                    Color.rgb(
                            124,
                            25,
                            238
                    ),
                    "↶"
            );

            drawCircleButton(
                    c,
                    w / 2f - 105,
                    y,
                    52,
                    Color.rgb(
                            244,
                            126,
                            72
                    ),
                    "↻"
            );

            drawRoundPanel(
                    c,
                    w / 2f - 45,
                    y - 32,
                    w / 2f + 145,
                    y + 32,
                    Color.rgb(
                            0,
                            155,
                            255
                    ),
                    Color.rgb(
                            34,
                            227,
                            255
                    )
            );

            text.setTextAlign(
                    Paint.Align.CENTER
            );

            text.setTypeface(
                    Typeface.DEFAULT_BOLD
            );

            text.setTextSize(14);

            text.setColor(Color.WHITE);

            c.drawText(
                    tr("حرکت‌ها", "Moves", "حرکتونه", "چالیں", "चालें", "الحركات"),
                    w / 2f + 50,
                    y - 4,
                    text
            );

            text.setTextSize(25);

            c.drawText(
                    String.valueOf(moves),
                    w / 2f + 50,
                    y + 23,
                    text
            );

            drawCircleButton(
                    c,
                    w - 75,
                    y,
                    52,
                    soundEnabled
                            ? Color.rgb(
                            49,
                            228,
                            36
                    )
                            : Color.rgb(
                            115,
                            115,
                            125
                    ),
                    soundEnabled
                            ? "♪"
                            : "×"
            );

            text.setTextSize(14);

            text.setColor(Color.WHITE);

            c.drawText(
                    tr("بازگشت", "Undo", "بېرته", "واپس", "वापस", "تراجع"),
                    75,
                    y + 78,
                    text
            );

            c.drawText(
                    tr("شروع دوباره", "Restart", "بیا پیل", "دوبارہ شروع", "फिर शुरू करें", "إعادة البدء"),
                    w / 2f - 105,
                    y + 78,
                    text
            );

            c.drawText(
                    tr("صدا", "Sound", "غږ", "آواز", "ध्वनि", "الصوت"),
                    w - 75,
                    y + 78,
                    text
            );

            drawBadgeCircle(
                    c,
                    99,
                    y - 43,
                    String.valueOf(
                            Math.max(
                                    0,
                                    MAX_MISTAKES -
                                            mistakes
                            )
                    )
            );

        }

        /* =========================================================
           FOOTER
           ========================================================= */

        private void drawFooter(
                Canvas c,
                float w,
                float h
        ) {

            float top =
                    h - 112;

            p.setShader(
                    new LinearGradient(
                            0,
                            top,
                            0,
                            h,
                            Color.rgb(
                                    94,
                                    14,
                                    220
                            ),
                            Color.rgb(
                                    31,
                                    10,
                                    115
                            ),
                            Shader.TileMode.CLAMP
                    )
            );

            c.drawRect(
                    0,
                    top,
                    w,
                    h,
                    p
            );

            p.setShader(null);

            text.setTypeface(
                    Typeface.DEFAULT_BOLD
            );

            text.setTextAlign(
                    Paint.Align.CENTER
            );

            text.setTextSize(19);

            text.setColor(Color.WHITE);

            c.drawText(
                    tr("رنگ‌ها را به درستی مرتب کنید", "Sort the colors correctly", "رنګونه په سمه توګه ترتیب کړئ", "رنگوں کو درست ترتیب دیں", "रंगों को सही क्रम में लगाएँ", "رتّب الألوان بشكل صحيح"),
                    w / 2f,
                    top + 43,
                    text
            );

            text.setTextSize(12);

            text.setColor(
                    Color.rgb(
                            255,
                            218,
                            60
                    )
            );

            c.drawText(
                    tr("جوایز مرحله: ★ 40   ★★ 70   ★★★ 100 سکه", "Level rewards: ★ 40   ★★ 70   ★★★ 100 coins", "د مرحلې انعامونه: ★ 40   ★★ 70   ★★★ 100 سکې", "مرحلے کے انعامات: ★ 40   ★★ 70   ★★★ 100 سکے", "स्तर के पुरस्कार: ★ 40   ★★ 70   ★★★ 100 सिक्के", "مكافآت المرحلة: ★ 40   ★★ 70   ★★★ 100 قطعة"),
                    w / 2f,
                    top + 73,
                    text
            );

            text.setTextSize(11);

            text.setColor(
                    Color.argb(
                            230,
                            220,
                            235,
                            255
                    )
            );

            c.drawText(
                    tr("مرحله ", "Level ", "مرحله ", "مرحلہ ", "स्तर ", "المرحلة ") +
                            level +
                            tr(" از ", " of ", " له ", " از ", " में से ", " من ") + MAX_LEVEL + tr("   •   خطا: ", "   •   Mistakes: ", "   •   تېروتنې: ", "   •   غلطیاں: ", "   •   गलतियाँ: ", "   •   أخطاء: ") +
                            mistakes +
                            "/" +
                            MAX_MISTAKES +
                            tr("   •   سکه: ", "   •   Coins: ", "   •   سکې: ", "   •   سکے: ", "   •   सिक्के: ", "   •   العملات: ") +
                            coins,
                    w / 2f,
                    top + 96,
                    text
            );
        }

        /* =========================================================
           ERROR MARK
           ========================================================= */

        private void drawErrorMark(
                Canvas c,
                float w,
                float h
        ) {

            float[] geometry = null;

            if (errorTo >= 0) {
                geometry =
                        getTubeGeometry(
                                errorTo
                        );
            } else if (errorFrom >= 0) {
                geometry =
                        getTubeGeometry(
                                errorFrom
                        );
            }

            if (geometry == null) {
                return;
            }

            float x = geometry[0];

            float y =
                    geometry[1]
                            -
                            geometry[3] / 2f
                            -
                            20;

            long elapsed =
                    SystemClock.uptimeMillis()
                            - errorStart;

            float progress =
                    Math.min(
                            1f,
                            elapsed / 650f
                    );

            float alpha =
                    1f - progress;

            float radius =
                    18f +
                            progress * 7f;

            p.setColor(
                    Color.argb(
                            (int)
                                    (230 * alpha),
                            220,
                            25,
                            45
                    )
            );

            c.drawCircle(
                    x,
                    y,
                    radius,
                    p
            );

            stroke.setStyle(
                    Paint.Style.STROKE
            );

            stroke.setStrokeWidth(4);

            stroke.setStrokeCap(
                    Paint.Cap.ROUND
            );

            stroke.setColor(
                    Color.argb(
                            (int)
                                    (255 * alpha),
                            255,
                            255,
                            255
                    )
            );

            c.drawLine(
                    x - 7,
                    y - 7,
                    x + 7,
                    y + 7,
                    stroke
            );

            c.drawLine(
                    x + 7,
                    y - 7,
                    x - 7,
                    y + 7,
                    stroke
            );

            stroke.setStrokeCap(
                    Paint.Cap.BUTT
            );
        }

        /* =========================================================
           VICTORY
           ========================================================= */

        private void drawVictory(
                Canvas c,
                float w,
                float h
        ) {

            p.setColor(
                    Color.argb(
                            210,
                            4,
                            8,
                            45
                    )
            );

            c.drawRect(
                    0,
                    0,
                    w,
                    h,
                    p
            );

            p.setColor(
                    Color.argb(
                            85,
                            80,
                            20,
                            255
                    )
            );

            p.setShadowLayer(
                    30,
                    0,
                    0,
                    Color.MAGENTA
            );

            c.drawRoundRect(
                    new RectF(
                            28,
                            h / 2f - 170,
                            w - 28,
                            h / 2f + 175
                    ),
                    35,
                    35,
                    p
            );

            p.clearShadowLayer();

            drawVictoryParticles(
                    c,
                    w,
                    h
            );

            text.setTextAlign(
                    Paint.Align.CENTER
            );

            text.setTypeface(
                    Typeface.DEFAULT_BOLD
            );

            text.setColor(Color.WHITE);

            text.setTextSize(31);

            c.drawText(
                    tr("عالی! مرحله کامل شد", "Great! Level completed", "ډېر ښه! مرحله بشپړه شوه", "زبردست! مرحلہ مکمل ہو گیا", "शानदार! स्तर पूरा हुआ", "رائع! اكتملت المرحلة"),
                    w / 2f,
                    h / 2f - 98,
                    text
            );

            int stars =
                    calculateStars();

            text.setTextSize(38);

            text.setColor(
                    Color.rgb(
                            255,
                            210,
                            35
                    )
            );

            String starsText = "";

            for (int i = 0; i < 3; i++) {

                starsText +=
                        i < stars
                                ? "★"
                                : "☆";
            }

            c.drawText(
                    starsText,
                    w / 2f,
                    h / 2f - 38,
                    text
            );

            text.setTextSize(18);

            text.setColor(Color.WHITE);

            c.drawText(
                    tr("مرحله ", "Level ", "مرحله ", "مرحلہ ", "स्तर ", "المرحلة ") +
                            level +
                            tr(" کامل شد", " completed", " بشپړه شوه", " مکمل ہوا", " पूरा हुआ", " اكتملت"),
                    w / 2f,
                    h / 2f + 10,
                    text
            );

            text.setTextSize(15);

            text.setColor(
                    Color.rgb(
                            255,
                            225,
                            80
                    )
            );

            c.drawText(
                    tr("جایزه: +", "Reward: +", "انعام: +", "انعام: +", "इनाम: +", "المكافأة: +") +
                            lastEarnedCoins +
                            tr(" سکه", " coins", " سکې", " سکے", " सिक्के", " قطعة"),
                    w / 2f,
                    h / 2f + 48,
                    text
            );

            text.setColor(
                    Color.rgb(
                            210,
                            230,
                            255
                    )
            );

            c.drawText(
                    tr("امتیاز کل: ", "Total score: ", "ټولې نمرې: ", "کل اسکور: ", "कुल अंक: ", "المجموع: ") +
                            coins +
                            tr(" سکه", " coins", " سکې", " سکے", " सिक्के", " قطعة"),
                    w / 2f,
                    h / 2f + 78,
                    text
            );

            drawActionButton(
                    c,
                    w / 2f,
                    h / 2f + 122,
                    tr("ادامه", "Continue", "دوام", "جاری رکھیں", "जारी रखें", "متابعة")
            );
        }

        /* =========================================================
           FAILURE
           ========================================================= */

        private void drawFailure(
                Canvas c,
                float w,
                float h
        ) {

            p.setColor(
                    Color.argb(
                            220,
                            20,
                            4,
                            20
                    )
            );

            c.drawRect(
                    0,
                    0,
                    w,
                    h,
                    p
            );

            p.setColor(
                    Color.argb(
                            90,
                            210,
                            15,
                            45
                    )
            );

            p.setShadowLayer(
                    30,
                    0,
                    0,
                    Color.RED
            );

            c.drawRoundRect(
                    new RectF(
                            28,
                            h / 2f - 155,
                            w - 28,
                            h / 2f + 160
                    ),
                    35,
                    35,
                    p
            );

            p.clearShadowLayer();

            text.setTextAlign(
                    Paint.Align.CENTER
            );

            text.setTypeface(
                    Typeface.DEFAULT_BOLD
            );

            text.setColor(
                    Color.rgb(
                            255,
                            75,
                            90
                    )
            );

            text.setTextSize(30);

            c.drawText(
                    tr("مرحله تمام نشد", "Level failed", "مرحله ناکامه شوه", "مرحلہ ناکام ہو گیا", "स्तर असफल हुआ", "لم تكتمل المرحلة"),
                    w / 2f,
                    h / 2f - 85,
                    text
            );

            text.setTextSize(18);

            text.setColor(Color.WHITE);

            c.drawText(
                    tr("سه خطا انجام شد", "Three mistakes made", "درې تېروتنې وشوې", "تین غلطیاں ہوئیں", "तीन गलतियाँ हुईं", "حدثت ثلاثة أخطاء"),
                    w / 2f,
                    h / 2f - 42,
                    text
            );

            text.setTextSize(15);

            text.setColor(
                    Color.rgb(
                            215,
                            225,
                            255
                    )
            );

            c.drawText(
                    tr("نگران نباش؛ مرحله دوباره از اول شروع می‌شود.", "Do not worry; the level will restart.", "اندېښنه مه کوئ؛ مرحله به بیا پیل شي.", "فکر نہ کریں؛ مرحلہ دوبارہ شروع ہوگا۔", "चिंता न करें; स्तर फिर शुरू होगा।", "لا تقلق؛ ستبدأ المرحلة من جديد."),
                    w / 2f,
                    h / 2f - 5,
                    text
            );

            drawActionButton(
                    c,
                    w / 2f,
                    h / 2f + 65,
                    tr("دوباره تلاش کن", "Try again", "بیا هڅه وکړئ", "دوبارہ کوشش کریں", "फिर कोशिश करें", "حاول مجدداً")
            );
        }

        private void drawActionButton(
                Canvas c,
                float x,
                float y,
                String label
        ) {

            float width = 170;
            float height = 54;

            p.setShader(
                    new LinearGradient(
                            x - width / 2,
                            y - height / 2,
                            x + width / 2,
                            y + height / 2,
                            Color.rgb(
                                    0,
                                    180,
                                    255
                            ),
                            Color.rgb(
                                    123,
                                    34,
                                    245
                            ),
                            Shader.TileMode.CLAMP
                    )
            );

            p.setShadowLayer(
                    12,
                    0,
                    5,
                    Color.argb(
                            170,
                            0,
                            0,
                            0
                    )
            );

            c.drawRoundRect(
                    new RectF(
                            x - width / 2,
                            y - height / 2,
                            x + width / 2,
                            y + height / 2
                    ),
                    18,
                    18,
                    p
            );

            p.clearShadowLayer();

            p.setShader(null);

            stroke.setStyle(
                    Paint.Style.STROKE
            );

            stroke.setStrokeWidth(2);

            stroke.setColor(
                    Color.argb(
                            210,
                            255,
                            255,
                            255
                    )
            );

            c.drawRoundRect(
                    new RectF(
                            x - width / 2,
                            y - height / 2,
                            x + width / 2,
                            y + height / 2
                    ),
                    18,
                    18,
                    stroke
            );

            text.setTextAlign(
                    Paint.Align.CENTER
            );

            text.setTypeface(
                    Typeface.DEFAULT_BOLD
            );

            text.setTextSize(17);

            text.setColor(Color.WHITE);

            c.drawText(
                    label,
                    x,
                    y + 6,
                    text
            );
        }

        /* =========================================================
           VICTORY PARTICLES
           ========================================================= */

        private void prepareVictoryParticles() {

            for (int i = 0;
                 i < particleX.length;
                 i++) {

                particleX[i] =
                        sparkleRandom.nextFloat();

                particleY[i] =
                        sparkleRandom.nextFloat();

                particleSpeed[i] =
                        18f +
                                sparkleRandom.nextFloat()
                                        * 55f;

                particleSize[i] =
                        2f +
                                sparkleRandom.nextFloat()
                                        * 4f;

                particlePhase[i] =
                        sparkleRandom.nextFloat()
                                        * 6.28f;
            }
        }

        private void drawVictoryParticles(
                Canvas c,
                float w,
                float h
        ) {

            long now =
                    SystemClock.uptimeMillis();

            float age =
                    victoryStart <= 0
                            ? 0f
                            : (
                            now -
                                    victoryStart
                    ) / 1000f;

            for (int i = 0;
                 i < particleX.length;
                 i++) {

                float x =
                        particleX[i] *
                                w
                                +
                                (float)
                                        Math.sin(
                                                age * 1.4f +
                                                        particlePhase[i]
                                        )
                                        * 14f;

                float y =
                        h * .18f
                                +
                                (
                                        particleY[i]
                                                *
                                                h * .58f
                                )
                                +
                                age *
                                        particleSpeed[i];

                y %= h * .72f;

                y += h * .15f;

                float alpha =
                        190f *
                                Math.max(
                                        0f,
                                        1f -
                                                age / 3.8f
                                );

                p.setColor(
                        Color.argb(
                                (int) alpha,
                                255,
                                190 +
                                        (i % 3) *
                                                20,
                                55
                        )
                );

                c.drawCircle(
                        x,
                        y,
                        particleSize[i],
                        p
                );
            }
        }

        /* =========================================================
           STARS / REWARD
           ========================================================= */

        private int calculateStars() {

            int perfect =
                    getColorCount() * 3;

            if (moves <= perfect) {
                return 3;
            }

            if (moves <= perfect + 7) {
                return 2;
            }

            return 1;
        }

        private int calculateReward(
                int stars
        ) {

            if (stars == 3) {
                return 100;
            }

            if (stars == 2) {
                return 70;
            }

            return 40;
        }

        /* =========================================================
           PANELS / BUTTONS
           ========================================================= */

        private void drawRoundPanel(
                Canvas c,
                float left,
                float top,
                float right,
                float bottom,
                int color1,
                int color2
        ) {

            if (right <= left ||
                    bottom <= top) {
                return;
            }

            p.setStyle(
                    Paint.Style.FILL
            );

            p.setShader(
                    new LinearGradient(
                            left,
                            top,
                            right,
                            bottom,
                            color1,
                            color2,
                            Shader.TileMode.CLAMP
                    )
            );

            p.setShadowLayer(
                    10,
                    0,
                    5,
                    Color.argb(
                            150,
                            0,
                            0,
                            0
                    )
            );

            c.drawRoundRect(
                    new RectF(
                            left,
                            top,
                            right,
                            bottom
                    ),
                    20,
                    20,
                    p
            );

            p.clearShadowLayer();

            p.setShader(null);

            stroke.setStyle(
                    Paint.Style.STROKE
            );

            stroke.setStrokeWidth(2);

            stroke.setColor(
                    Color.argb(
                            180,
                            255,
                            255,
                            255
                    )
            );

            c.drawRoundRect(
                    new RectF(
                            left,
                            top,
                            right,
                            bottom
                    ),
                    20,
                    20,
                    stroke
            );
        }

        private void drawCircleButton(
                Canvas c,
                float x,
                float y,
                float radius,
                int color,
                String symbol
        ) {

            p.setColor(color);

            p.setShadowLayer(
                    12,
                    0,
                    6,
                    Color.argb(
                            160,
                            0,
                            0,
                            0
                    )
            );

            c.drawCircle(
                    x,
                    y,
                    radius,
                    p
            );

            p.clearShadowLayer();

            stroke.setStyle(
                    Paint.Style.STROKE
            );

            stroke.setStrokeWidth(2);

            stroke.setColor(
                    Color.argb(
                            190,
                            255,
                            255,
                            255
                    )
            );

            c.drawCircle(
                    x,
                    y,
                    radius - 2,
                    stroke
            );

            text.setTextAlign(
                    Paint.Align.CENTER
            );

            text.setTypeface(
                    Typeface.DEFAULT_BOLD
            );

            text.setTextSize(29);

            text.setColor(Color.WHITE);

            c.drawText(
                    symbol,
                    x,
                    y + 10,
                    text
            );
        }

        private void drawBadgeCircle(
                Canvas c,
                float x,
                float y,
                String value
        ) {

            p.setColor(
                    Color.rgb(
                            245,
                            24,
                            65
                    )
            );

            c.drawCircle(
                    x,
                    y,
                    16,
                    p
            );

            text.setTextAlign(
                    Paint.Align.CENTER
            );

            text.setTextSize(13);

            text.setTypeface(
                    Typeface.DEFAULT_BOLD
            );

            text.setColor(Color.WHITE);

            c.drawText(
                    value,
                    x,
                    y + 5,
                    text
            );
        }

        private void drawCoin(
                Canvas c,
                float x,
                float y
        ) {

            p.setColor(
                    Color.rgb(
                            255,
                            193,
                            15
                    )
            );

            p.setShadowLayer(
                    7,
                    0,
                    2,
                    Color.rgb(
                            255,
                            120,
                            0
                    )
            );

            c.drawCircle(
                    x,
                    y,
                    19,
                    p
            );

            p.clearShadowLayer();

            stroke.setStyle(
                    Paint.Style.STROKE
            );

            stroke.setStrokeWidth(2);

            stroke.setColor(
                    Color.rgb(
                            255,
                            235,
                            100
                    )
            );

            c.drawCircle(
                    x,
                    y,
                    15,
                    stroke
            );

            text.setTextAlign(
                    Paint.Align.CENTER
            );

            text.setTextSize(18);

            text.setColor(
                    Color.rgb(
                            160,
                            91,
                            0
                    )
            );

            text.setTypeface(
                    Typeface.DEFAULT_BOLD
            );

            c.drawText(
                    "$",
                    x,
                    y + 6,
                    text
            );
        }

        private void drawStar(
                Canvas c,
                float cx,
                float cy,
                float radius,
                int color
        ) {

            p.setColor(color);

            p.setShadowLayer(
                    8,
                    0,
                    2,
                    Color.rgb(
                            255,
                            125,
                            0
                    )
            );

            Path path =
                    new Path();

            for (int i = 0;
                 i < 10;
                 i++) {

                double angle =
                        -Math.PI / 2
                                +
                                i *
                                        Math.PI /
                                                5;

                float r =
                        i % 2 == 0
                                ? radius
                                : radius * .42f;

                float x =
                        cx +
                                (float)
                                        Math.cos(angle)
                                        * r;

                float y =
                        cy +
                                (float)
                                        Math.sin(angle)
                                        * r;

                if (i == 0) {
                    path.moveTo(
                            x,
                            y
                    );
                } else {
                    path.lineTo(
                            x,
                            y
                    );
                }
            }

            path.close();

            c.drawPath(
                    path,
                    p
            );

            p.clearShadowLayer();
        }

        /* =========================================================
           COLOR HELPERS
           ========================================================= */

        private int lighten(
                int color,
                float factor
        ) {

            return Color.rgb(
                    Math.min(
                            255,
                            (int)
                                    (
                                            Color.red(color)
                                                    * factor
                                    )
                    ),
                    Math.min(
                            255,
                            (int)
                                    (
                                            Color.green(color)
                                                    * factor
                                    )
                    ),
                    Math.min(
                            255,
                            (int)
                                    (
                                            Color.blue(color)
                                                    * factor
                                    )
                    )
            );
        }

        private int darken(
                int color,
                float factor
        ) {

            return Color.rgb(
                    Math.max(
                            0,
                            (int)
                                    (
                                            Color.red(color)
                                                    * factor
                                    )
                    ),
                    Math.max(
                            0,
                            (int)
                                    (
                                            Color.green(color)
                                                    * factor
                                    )
                    ),
                    Math.max(
                            0,
                            (int)
                                    (
                                            Color.blue(color)
                                                    * factor
                                    )
                    )
            );
        }

        /* =========================================================
           TOUCH
           ========================================================= */

        @Override
        public boolean onTouchEvent(
                MotionEvent event
        ) {

            if (event.getAction() !=
                    MotionEvent.ACTION_DOWN) {

                return true;
            }

            float x =
                    event.getX();

            float y =
                    event.getY();

            float h =
                    getHeight();

            float w =
                    getWidth();

            // The home tile is visible in the header, so make its hit area real.
            if (x >= 8f && x <= 88f && y >= 8f && y <= 88f) {
                saveProgress();
                finish();
                return true;
            }

            /* ---------------------------------
               FAILURE SCREEN
               --------------------------------- */

            if (levelFailed) {

                float retryY =
                        h / 2f + 65;

                if (
                        Math.abs(
                                x - w / 2f
                        ) < 100
                                &&
                                Math.abs(
                                        y - retryY
                                ) < 40
                ) {

                    playGameSound(1);

                    resetLevel();

                    return true;
                }

                return true;
            }

            /* ---------------------------------
               VICTORY SCREEN
               --------------------------------- */

            if (levelFinished) {

                float continueY =
                        h / 2f + 122;

                if (
                        Math.abs(
                                x - w / 2f
                        ) < 105
                                &&
                                Math.abs(
                                        y - continueY
                                ) < 42
                ) {

                    advanceAfterVictory();

                    return true;
                }

                return true;
            }

            /* ---------------------------------
               CONTROLS
               --------------------------------- */

            float controlY =
                    h - 205;

            if (
                    distance(
                            x,
                            y,
                            75,
                            controlY
                    ) < 65
            ) {

                undoMove();

                return true;
            }

            if (
                    distance(
                            x,
                            y,
                            w / 2f - 105,
                            controlY
                    ) < 65
            ) {
                playGameSound(1);
                resetLevel();
                return true;
            }

            if (
                    distance(
                            x,
                            y,
                            w - 75,
                            controlY
                    ) < 65
            ) {

                soundEnabled =
                        !soundEnabled;

                saveProgress();

                if (soundEnabled) {
                    startAmbientMusic();
                    playGameSound(1);
                } else {
                    stopAmbientMusic();
                    stopActiveSound();
                }

                invalidate();

                return true;
            }

            /* ---------------------------------
               TUBE
               --------------------------------- */

            int tube =
                    findTube(
                            x,
                            y
                    );

            if (tube >= 0) {

                handleTubeClick(
                        tube
                );
            }

            return true;
        }

        private float distance(
                float x1,
                float y1,
                float x2,
                float y2
        ) {

            float dx =
                    x1 - x2;

            float dy =
                    y1 - y2;

            return (float)
                    Math.sqrt(
                            dx * dx +
                                    dy * dy
                    );
        }

        private int findTube(
                float x,
                float y
        ) {

            for (int i = 0;
                 i < tubes.size();
                 i++) {

                float[] geometry =
                        getTubeGeometry(i);

                float left =
                        geometry[0]
                                -
                                geometry[2] / 2
                                -
                                18;

                float right =
                        geometry[0]
                                +
                                geometry[2] / 2
                                +
                                18;

                float top =
                        geometry[1]
                                -
                                geometry[3] / 2
                                -
                                20;

                float bottom =
                        geometry[1]
                                +
                                geometry[3] / 2
                                +
                                30;

                if (
                        x >= left &&
                                x <= right &&
                                y >= top &&
                                y <= bottom
                ) {

                    return i;
                }
            }

            return -1;
        }

        /* =========================================================
           TUBE CLICK
           ========================================================= */

        private void handleTubeClick(
                int index
        ) {

            if (animProgress < 1f) {
                return;
            }

            if (levelFinished ||
                    levelFailed) {

                return;
            }

            if (selectedTube == -1) {

                if (
                        tubes
                                .get(index)
                                .isEmpty()
                ) {

                    playGameSound(4);

                    showError(
                            index,
                            -1,
                            false
                    );

                    return;
                }

                selectedTube =
                        index;

                playGameSound(1);

                invalidate();

                return;
            }

            if (selectedTube == index) {

                selectedTube = -1;

                invalidate();

                return;
            }

            if (
                    canMove(
                            selectedTube,
                            index
                    )
            ) {

                int from =
                        selectedTube;

                saveMove(
                        from,
                        index
                );

                beginAnimatedMove(
                        from,
                        index
                );

                moves++;

                selectedTube = -1;

            } else {

                showError(
                        selectedTube,
                        index,
                        true
                );

                selectedTube = -1;
            }
        }

        /* =========================================================
           ERROR
           ========================================================= */

        private void showError(
                int from,
                int to,
                boolean countMistake
        ) {

            errorFrom = from;
            errorTo = to;

            if (countMistake) {

                mistakes++;

                errorStrength =
                        mistakes >= 2
                                ? 2
                                : 1;

                playGameSound(4);

                errorStart =
                        SystemClock.uptimeMillis();

                invalidate();

                if (mistakes >= MAX_MISTAKES) {

                    handler.postDelayed(
                            new Runnable() {

                                @Override
                                public void run() {

                                    if (
                                            mistakes >=
                                                    MAX_MISTAKES
                                                    &&
                                                    !levelFinished
                                    ) {

                                        failLevel();
                                    }
                                }
                            },
                            700
                    );
                }

            } else {

                errorStrength = 1;

                errorStart =
                        SystemClock.uptimeMillis();

                invalidate();
            }
        }

        /* =========================================================
           MOVE VALIDATION
           ========================================================= */

        private boolean canMove(
                int from,
                int to
        ) {

            if (
                    from < 0 ||
                            to < 0 ||
                            from >= tubes.size() ||
                            to >= tubes.size()
            ) {

                return false;
            }

            List<Integer> source =
                    tubes.get(from);

            List<Integer> target =
                    tubes.get(to);

            if (
                    source.isEmpty() ||
                            target.size() >= CAPACITY
            ) {

                return false;
            }

            int color =
                    source.get(
                            source.size() - 1
                    );

            return target.isEmpty()
                    ||
                    target.get(
                            target.size() - 1
                    ) == color;
        }

        /* =========================================================
           ANIMATED MOVE
           ========================================================= */

        private void beginAnimatedMove(
                int from,
                int to
        ) {

            List<Integer> source =
                    tubes.get(from);

            animFrom = from;
            animTo = to;

            animColor =
                    source.get(
                            source.size() - 1
                    );

            animAmount =
                    Math.min(
                            getTopSameCount(
                                    source
                            ),
                            CAPACITY -
                                    tubes
                                            .get(to)
                                            .size()
                    );

            animProgress = 0f;

            animStart =
                    SystemClock.uptimeMillis();

            playGameSound(2);

            invalidate();
        }

        private void finishAnimatedMove() {

            if (
                    animFrom < 0 ||
                            animTo < 0
            ) {

                return;
            }

            moveColor(
                    animFrom,
                    animTo
            );

            animFrom = -1;
            animTo = -1;
            animColor = -1;
            animAmount = 0;
            animProgress = 1f;

            if (isLevelComplete()) {

                completeLevel();

            } else {

                playGameSound(1);
            }

            saveProgress();

            invalidate();
        }

        private void moveColor(
                int from,
                int to
        ) {

            List<Integer> source =
                    tubes.get(from);

            List<Integer> target =
                    tubes.get(to);

            if (source.isEmpty()) {
                return;
            }

            int color =
                    source.get(
                            source.size() - 1
                    );

            while (
                    !source.isEmpty()
                            &&
                            target.size() < CAPACITY
                            &&
                            source.get(
                                    source.size() - 1
                            ) == color
            ) {

                target.add(
                        source.remove(
                                source.size() - 1
                        )
                );
            }
        }

        /* =========================================================
           UNDO
           ========================================================= */

        void undoMove() {

            if (
                    levelFinished ||
                            levelFailed ||
                            animProgress < 1f
            ) {

                return;
            }

            if (history.isEmpty()) {

                Toast.makeText(
                        ColorSortActivity.this,
                        tr("حرکتی برای برگشت وجود ندارد", "No move to undo", "د بېرته ګرځولو حرکت نشته", "واپس جانے کے لیے کوئی چال نہیں", "वापस जाने की कोई चाल नहीं", "لا توجد حركة للتراجع"),
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            Move move =
                    history.remove(
                            history.size() - 1
                    );

            List<Integer> source =
                    tubes.get(move.to);

            List<Integer> target =
                    tubes.get(move.from);

            for (
                    int i = 0;
                    i < move.amount;
                    i++
            ) {

                if (!source.isEmpty()) {

                    target.add(
                            source.remove(
                                    source.size() - 1
                            )
                    );
                }
            }

            moves =
                    Math.max(
                            0,
                            moves - 1
                    );

            playGameSound(1);

            invalidate();
        }

        /* =========================================================
           SAVE MOVE
           ========================================================= */

        private void saveMove(
                int from,
                int to
        ) {

            List<Integer> source =
                    tubes.get(from);

            if (source.isEmpty()) {
                return;
            }

            int color =
                    source.get(
                            source.size() - 1
                    );

            int amount =
                    Math.min(
                            getTopSameCount(
                                    source
                            ),
                            CAPACITY -
                                    tubes
                                            .get(to)
                                            .size()
                    );

            history.add(
                    new Move(
                            from,
                            to,
                            color,
                            amount
                    )
            );

            if (history.size() > 100) {
                history.remove(0);
            }
        }

        /* =========================================================
           COMPLETE LEVEL
           ========================================================= */

        private boolean isLevelComplete() {

            for (
                    List<Integer> tube :
                    tubes
            ) {

                if (tube.isEmpty()) {
                    continue;
                }

                if (tube.size() != CAPACITY) {
                    return false;
                }

                int first =
                        tube.get(0);

                for (
                        int i = 1;
                        i < tube.size();
                        i++
                ) {

                    if (
                            tube.get(i) != first
                    ) {

                        return false;
                    }
                }
            }

            return true;
        }

        private void completeLevel() {

            if (levelFinished ||
                    levelFailed) {

                return;
            }

            levelFinished = true;

            selectedTube = -1;

            int stars =
                    calculateStars();

            lastEarnedCoins =
                    calculateReward(stars);

            coins +=
                    lastEarnedCoins;

            totalStars +=
                    stars;

            victoryStart =
                    SystemClock.uptimeMillis();

            /*
             * فقط یک بار صدای جشن را اجرا می‌کنیم.
             * این صدا حدود ۳.۴ ثانیه طول دارد.
             */
            playGameSound(3);

            saveProgress();

            invalidate();

            handler.postDelayed(
                    new Runnable() {

                        @Override
                        public void run() {

                            if (!levelFinished) {
                                return;
                            }

                            advanceAfterVictory();
                        }
                    },
                    3600
            );
        }

        private void advanceAfterVictory() {

            if (!levelFinished) {
                return;
            }

            levelFinished = false;

            if (level < MAX_LEVEL) {

                level++;

                saveProgress();

                resetLevel();

            } else {

                Toast.makeText(
                        ColorSortActivity.this,
                        tr("🏆 هر ۵۰ مرحله را کامل کردی!", "🏆 You completed all 50 levels!", "🏆 تاسو ټولې ۵۰ مرحلې بشپړې کړې!", "🏆 آپ نے تمام ۵۰ مرحلے مکمل کر لیے!", "🏆 आपने सभी ५० स्तर पूरे कर लिए!", "🏆 أكملت جميع المراحل الخمسين!"),
                        Toast.LENGTH_LONG
                ).show();

                level = 1;

                saveProgress();

                resetLevel();
            }
        }

        /* =========================================================
           FAILURE
           ========================================================= */

        private void failLevel() {

            if (
                    levelFinished ||
                            levelFailed
            ) {

                return;
            }

            levelFailed = true;

            selectedTube = -1;

            failureStart =
                    SystemClock.uptimeMillis();

            stopActiveSound();

            playGameSound(4);

            invalidate();
        }

        /* =========================================================
           MOVE OBJECT
           ========================================================= */

        class Move {

            int from;
            int to;
            int color;
            int amount;

            Move(
                    int from,
                    int to,
                    int color,
                    int amount
            ) {

                this.from = from;
                this.to = to;
                this.color = color;
                this.amount = amount;
            }
        }
    }
                                     }
